"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn2, res) => function __init() {
    return fn2 && (res = (0, fn2[__getOwnPropNames(fn2)[0]])(fn2 = 0)), res;
  };
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // node_modules/preact/dist/preact.module.js
  function s(n2, l3) {
    for (var u3 in l3)
      n2[u3] = l3[u3];
    return n2;
  }
  function a(n2) {
    var l3 = n2.parentNode;
    l3 && l3.removeChild(n2);
  }
  function h(l3, u3, i3) {
    var t3, o4, r3, f3 = {};
    for (r3 in u3)
      "key" == r3 ? t3 = u3[r3] : "ref" == r3 ? o4 = u3[r3] : f3[r3] = u3[r3];
    if (arguments.length > 2 && (f3.children = arguments.length > 3 ? n.call(arguments, 2) : i3), "function" == typeof l3 && null != l3.defaultProps)
      for (r3 in l3.defaultProps)
        void 0 === f3[r3] && (f3[r3] = l3.defaultProps[r3]);
    return v(l3, f3, t3, o4, null);
  }
  function v(n2, i3, t3, o4, r3) {
    var f3 = { type: n2, props: i3, key: t3, ref: o4, __k: null, __: null, __b: 0, __e: null, __d: void 0, __c: null, __h: null, constructor: void 0, __v: null == r3 ? ++u : r3 };
    return null == r3 && null != l.vnode && l.vnode(f3), f3;
  }
  function y() {
    return { current: null };
  }
  function p(n2) {
    return n2.children;
  }
  function d(n2, l3) {
    this.props = n2, this.context = l3;
  }
  function _(n2, l3) {
    if (null == l3)
      return n2.__ ? _(n2.__, n2.__.__k.indexOf(n2) + 1) : null;
    for (var u3; l3 < n2.__k.length; l3++)
      if (null != (u3 = n2.__k[l3]) && null != u3.__e)
        return u3.__e;
    return "function" == typeof n2.type ? _(n2) : null;
  }
  function k(n2) {
    var l3, u3;
    if (null != (n2 = n2.__) && null != n2.__c) {
      for (n2.__e = n2.__c.base = null, l3 = 0; l3 < n2.__k.length; l3++)
        if (null != (u3 = n2.__k[l3]) && null != u3.__e) {
          n2.__e = n2.__c.base = u3.__e;
          break;
        }
      return k(n2);
    }
  }
  function b(n2) {
    (!n2.__d && (n2.__d = true) && t.push(n2) && !g.__r++ || o !== l.debounceRendering) && ((o = l.debounceRendering) || setTimeout)(g);
  }
  function g() {
    for (var n2; g.__r = t.length; )
      n2 = t.sort(function(n3, l3) {
        return n3.__v.__b - l3.__v.__b;
      }), t = [], n2.some(function(n3) {
        var l3, u3, i3, t3, o4, r3;
        n3.__d && (o4 = (t3 = (l3 = n3).__v).__e, (r3 = l3.__P) && (u3 = [], (i3 = s({}, t3)).__v = t3.__v + 1, j(r3, t3, i3, l3.__n, void 0 !== r3.ownerSVGElement, null != t3.__h ? [o4] : null, u3, null == o4 ? _(t3) : o4, t3.__h), z(u3, t3), t3.__e != o4 && k(t3)));
      });
  }
  function w(n2, l3, u3, i3, t3, o4, r3, c3, s3, a3) {
    var h3, y3, d3, k4, b3, g4, w4, x4 = i3 && i3.__k || e, C3 = x4.length;
    for (u3.__k = [], h3 = 0; h3 < l3.length; h3++)
      if (null != (k4 = u3.__k[h3] = null == (k4 = l3[h3]) || "boolean" == typeof k4 ? null : "string" == typeof k4 || "number" == typeof k4 || "bigint" == typeof k4 ? v(null, k4, null, null, k4) : Array.isArray(k4) ? v(p, { children: k4 }, null, null, null) : k4.__b > 0 ? v(k4.type, k4.props, k4.key, k4.ref ? k4.ref : null, k4.__v) : k4)) {
        if (k4.__ = u3, k4.__b = u3.__b + 1, null === (d3 = x4[h3]) || d3 && k4.key == d3.key && k4.type === d3.type)
          x4[h3] = void 0;
        else
          for (y3 = 0; y3 < C3; y3++) {
            if ((d3 = x4[y3]) && k4.key == d3.key && k4.type === d3.type) {
              x4[y3] = void 0;
              break;
            }
            d3 = null;
          }
        j(n2, k4, d3 = d3 || f, t3, o4, r3, c3, s3, a3), b3 = k4.__e, (y3 = k4.ref) && d3.ref != y3 && (w4 || (w4 = []), d3.ref && w4.push(d3.ref, null, k4), w4.push(y3, k4.__c || b3, k4)), null != b3 ? (null == g4 && (g4 = b3), "function" == typeof k4.type && k4.__k === d3.__k ? k4.__d = s3 = m(k4, s3, n2) : s3 = A(n2, k4, d3, x4, b3, s3), "function" == typeof u3.type && (u3.__d = s3)) : s3 && d3.__e == s3 && s3.parentNode != n2 && (s3 = _(d3));
      }
    for (u3.__e = g4, h3 = C3; h3--; )
      null != x4[h3] && N(x4[h3], x4[h3]);
    if (w4)
      for (h3 = 0; h3 < w4.length; h3++)
        M(w4[h3], w4[++h3], w4[++h3]);
  }
  function m(n2, l3, u3) {
    for (var i3, t3 = n2.__k, o4 = 0; t3 && o4 < t3.length; o4++)
      (i3 = t3[o4]) && (i3.__ = n2, l3 = "function" == typeof i3.type ? m(i3, l3, u3) : A(u3, i3, i3, t3, i3.__e, l3));
    return l3;
  }
  function x(n2, l3) {
    return l3 = l3 || [], null == n2 || "boolean" == typeof n2 || (Array.isArray(n2) ? n2.some(function(n3) {
      x(n3, l3);
    }) : l3.push(n2)), l3;
  }
  function A(n2, l3, u3, i3, t3, o4) {
    var r3, f3, e3;
    if (void 0 !== l3.__d)
      r3 = l3.__d, l3.__d = void 0;
    else if (null == u3 || t3 != o4 || null == t3.parentNode)
      n:
        if (null == o4 || o4.parentNode !== n2)
          n2.appendChild(t3), r3 = null;
        else {
          for (f3 = o4, e3 = 0; (f3 = f3.nextSibling) && e3 < i3.length; e3 += 1)
            if (f3 == t3)
              break n;
          n2.insertBefore(t3, o4), r3 = o4;
        }
    return void 0 !== r3 ? r3 : t3.nextSibling;
  }
  function C(n2, l3, u3, i3, t3) {
    var o4;
    for (o4 in u3)
      "children" === o4 || "key" === o4 || o4 in l3 || H(n2, o4, null, u3[o4], i3);
    for (o4 in l3)
      t3 && "function" != typeof l3[o4] || "children" === o4 || "key" === o4 || "value" === o4 || "checked" === o4 || u3[o4] === l3[o4] || H(n2, o4, l3[o4], u3[o4], i3);
  }
  function $(n2, l3, u3) {
    "-" === l3[0] ? n2.setProperty(l3, u3) : n2[l3] = null == u3 ? "" : "number" != typeof u3 || c.test(l3) ? u3 : u3 + "px";
  }
  function H(n2, l3, u3, i3, t3) {
    var o4;
    n:
      if ("style" === l3)
        if ("string" == typeof u3)
          n2.style.cssText = u3;
        else {
          if ("string" == typeof i3 && (n2.style.cssText = i3 = ""), i3)
            for (l3 in i3)
              u3 && l3 in u3 || $(n2.style, l3, "");
          if (u3)
            for (l3 in u3)
              i3 && u3[l3] === i3[l3] || $(n2.style, l3, u3[l3]);
        }
      else if ("o" === l3[0] && "n" === l3[1])
        o4 = l3 !== (l3 = l3.replace(/Capture$/, "")), l3 = l3.toLowerCase() in n2 ? l3.toLowerCase().slice(2) : l3.slice(2), n2.l || (n2.l = {}), n2.l[l3 + o4] = u3, u3 ? i3 || n2.addEventListener(l3, o4 ? T : I, o4) : n2.removeEventListener(l3, o4 ? T : I, o4);
      else if ("dangerouslySetInnerHTML" !== l3) {
        if (t3)
          l3 = l3.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
        else if ("href" !== l3 && "list" !== l3 && "form" !== l3 && "tabIndex" !== l3 && "download" !== l3 && l3 in n2)
          try {
            n2[l3] = null == u3 ? "" : u3;
            break n;
          } catch (n3) {
          }
        "function" == typeof u3 || (null == u3 || false === u3 && -1 == l3.indexOf("-") ? n2.removeAttribute(l3) : n2.setAttribute(l3, u3));
      }
  }
  function I(n2) {
    this.l[n2.type + false](l.event ? l.event(n2) : n2);
  }
  function T(n2) {
    this.l[n2.type + true](l.event ? l.event(n2) : n2);
  }
  function j(n2, u3, i3, t3, o4, r3, f3, e3, c3) {
    var a3, h3, v3, y3, _4, k4, b3, g4, m3, x4, A4, C3, $3, H3, I3, T4 = u3.type;
    if (void 0 !== u3.constructor)
      return null;
    null != i3.__h && (c3 = i3.__h, e3 = u3.__e = i3.__e, u3.__h = null, r3 = [e3]), (a3 = l.__b) && a3(u3);
    try {
      n:
        if ("function" == typeof T4) {
          if (g4 = u3.props, m3 = (a3 = T4.contextType) && t3[a3.__c], x4 = a3 ? m3 ? m3.props.value : a3.__ : t3, i3.__c ? b3 = (h3 = u3.__c = i3.__c).__ = h3.__E : ("prototype" in T4 && T4.prototype.render ? u3.__c = h3 = new T4(g4, x4) : (u3.__c = h3 = new d(g4, x4), h3.constructor = T4, h3.render = O), m3 && m3.sub(h3), h3.props = g4, h3.state || (h3.state = {}), h3.context = x4, h3.__n = t3, v3 = h3.__d = true, h3.__h = [], h3._sb = []), null == h3.__s && (h3.__s = h3.state), null != T4.getDerivedStateFromProps && (h3.__s == h3.state && (h3.__s = s({}, h3.__s)), s(h3.__s, T4.getDerivedStateFromProps(g4, h3.__s))), y3 = h3.props, _4 = h3.state, v3)
            null == T4.getDerivedStateFromProps && null != h3.componentWillMount && h3.componentWillMount(), null != h3.componentDidMount && h3.__h.push(h3.componentDidMount);
          else {
            if (null == T4.getDerivedStateFromProps && g4 !== y3 && null != h3.componentWillReceiveProps && h3.componentWillReceiveProps(g4, x4), !h3.__e && null != h3.shouldComponentUpdate && false === h3.shouldComponentUpdate(g4, h3.__s, x4) || u3.__v === i3.__v) {
              for (h3.props = g4, h3.state = h3.__s, u3.__v !== i3.__v && (h3.__d = false), h3.__v = u3, u3.__e = i3.__e, u3.__k = i3.__k, u3.__k.forEach(function(n3) {
                n3 && (n3.__ = u3);
              }), A4 = 0; A4 < h3._sb.length; A4++)
                h3.__h.push(h3._sb[A4]);
              h3._sb = [], h3.__h.length && f3.push(h3);
              break n;
            }
            null != h3.componentWillUpdate && h3.componentWillUpdate(g4, h3.__s, x4), null != h3.componentDidUpdate && h3.__h.push(function() {
              h3.componentDidUpdate(y3, _4, k4);
            });
          }
          if (h3.context = x4, h3.props = g4, h3.__v = u3, h3.__P = n2, C3 = l.__r, $3 = 0, "prototype" in T4 && T4.prototype.render) {
            for (h3.state = h3.__s, h3.__d = false, C3 && C3(u3), a3 = h3.render(h3.props, h3.state, h3.context), H3 = 0; H3 < h3._sb.length; H3++)
              h3.__h.push(h3._sb[H3]);
            h3._sb = [];
          } else
            do {
              h3.__d = false, C3 && C3(u3), a3 = h3.render(h3.props, h3.state, h3.context), h3.state = h3.__s;
            } while (h3.__d && ++$3 < 25);
          h3.state = h3.__s, null != h3.getChildContext && (t3 = s(s({}, t3), h3.getChildContext())), v3 || null == h3.getSnapshotBeforeUpdate || (k4 = h3.getSnapshotBeforeUpdate(y3, _4)), I3 = null != a3 && a3.type === p && null == a3.key ? a3.props.children : a3, w(n2, Array.isArray(I3) ? I3 : [I3], u3, i3, t3, o4, r3, f3, e3, c3), h3.base = u3.__e, u3.__h = null, h3.__h.length && f3.push(h3), b3 && (h3.__E = h3.__ = null), h3.__e = false;
        } else
          null == r3 && u3.__v === i3.__v ? (u3.__k = i3.__k, u3.__e = i3.__e) : u3.__e = L(i3.__e, u3, i3, t3, o4, r3, f3, c3);
      (a3 = l.diffed) && a3(u3);
    } catch (n3) {
      u3.__v = null, (c3 || null != r3) && (u3.__e = e3, u3.__h = !!c3, r3[r3.indexOf(e3)] = null), l.__e(n3, u3, i3);
    }
  }
  function z(n2, u3) {
    l.__c && l.__c(u3, n2), n2.some(function(u4) {
      try {
        n2 = u4.__h, u4.__h = [], n2.some(function(n3) {
          n3.call(u4);
        });
      } catch (n3) {
        l.__e(n3, u4.__v);
      }
    });
  }
  function L(l3, u3, i3, t3, o4, r3, e3, c3) {
    var s3, h3, v3, y3 = i3.props, p3 = u3.props, d3 = u3.type, k4 = 0;
    if ("svg" === d3 && (o4 = true), null != r3) {
      for (; k4 < r3.length; k4++)
        if ((s3 = r3[k4]) && "setAttribute" in s3 == !!d3 && (d3 ? s3.localName === d3 : 3 === s3.nodeType)) {
          l3 = s3, r3[k4] = null;
          break;
        }
    }
    if (null == l3) {
      if (null === d3)
        return document.createTextNode(p3);
      l3 = o4 ? document.createElementNS("http://www.w3.org/2000/svg", d3) : document.createElement(d3, p3.is && p3), r3 = null, c3 = false;
    }
    if (null === d3)
      y3 === p3 || c3 && l3.data === p3 || (l3.data = p3);
    else {
      if (r3 = r3 && n.call(l3.childNodes), h3 = (y3 = i3.props || f).dangerouslySetInnerHTML, v3 = p3.dangerouslySetInnerHTML, !c3) {
        if (null != r3)
          for (y3 = {}, k4 = 0; k4 < l3.attributes.length; k4++)
            y3[l3.attributes[k4].name] = l3.attributes[k4].value;
        (v3 || h3) && (v3 && (h3 && v3.__html == h3.__html || v3.__html === l3.innerHTML) || (l3.innerHTML = v3 && v3.__html || ""));
      }
      if (C(l3, p3, y3, o4, c3), v3)
        u3.__k = [];
      else if (k4 = u3.props.children, w(l3, Array.isArray(k4) ? k4 : [k4], u3, i3, t3, o4 && "foreignObject" !== d3, r3, e3, r3 ? r3[0] : i3.__k && _(i3, 0), c3), null != r3)
        for (k4 = r3.length; k4--; )
          null != r3[k4] && a(r3[k4]);
      c3 || ("value" in p3 && void 0 !== (k4 = p3.value) && (k4 !== l3.value || "progress" === d3 && !k4 || "option" === d3 && k4 !== y3.value) && H(l3, "value", k4, y3.value, false), "checked" in p3 && void 0 !== (k4 = p3.checked) && k4 !== l3.checked && H(l3, "checked", k4, y3.checked, false));
    }
    return l3;
  }
  function M(n2, u3, i3) {
    try {
      "function" == typeof n2 ? n2(u3) : n2.current = u3;
    } catch (n3) {
      l.__e(n3, i3);
    }
  }
  function N(n2, u3, i3) {
    var t3, o4;
    if (l.unmount && l.unmount(n2), (t3 = n2.ref) && (t3.current && t3.current !== n2.__e || M(t3, null, u3)), null != (t3 = n2.__c)) {
      if (t3.componentWillUnmount)
        try {
          t3.componentWillUnmount();
        } catch (n3) {
          l.__e(n3, u3);
        }
      t3.base = t3.__P = null, n2.__c = void 0;
    }
    if (t3 = n2.__k)
      for (o4 = 0; o4 < t3.length; o4++)
        t3[o4] && N(t3[o4], u3, i3 || "function" != typeof n2.type);
    i3 || null == n2.__e || a(n2.__e), n2.__ = n2.__e = n2.__d = void 0;
  }
  function O(n2, l3, u3) {
    return this.constructor(n2, u3);
  }
  function P(u3, i3, t3) {
    var o4, r3, e3;
    l.__ && l.__(u3, i3), r3 = (o4 = "function" == typeof t3) ? null : t3 && t3.__k || i3.__k, e3 = [], j(i3, u3 = (!o4 && t3 || i3).__k = h(p, null, [u3]), r3 || f, f, void 0 !== i3.ownerSVGElement, !o4 && t3 ? [t3] : r3 ? null : i3.firstChild ? n.call(i3.childNodes) : null, e3, !o4 && t3 ? t3 : r3 ? r3.__e : i3.firstChild, o4), z(e3, u3);
  }
  function S(n2, l3) {
    P(n2, l3, S);
  }
  function q(l3, u3, i3) {
    var t3, o4, r3, f3 = s({}, l3.props);
    for (r3 in u3)
      "key" == r3 ? t3 = u3[r3] : "ref" == r3 ? o4 = u3[r3] : f3[r3] = u3[r3];
    return arguments.length > 2 && (f3.children = arguments.length > 3 ? n.call(arguments, 2) : i3), v(l3.type, f3, t3 || l3.key, o4 || l3.ref, null);
  }
  function B(n2, l3) {
    var u3 = { __c: l3 = "__cC" + r++, __: n2, Consumer: function(n3, l4) {
      return n3.children(l4);
    }, Provider: function(n3) {
      var u4, i3;
      return this.getChildContext || (u4 = [], (i3 = {})[l3] = this, this.getChildContext = function() {
        return i3;
      }, this.shouldComponentUpdate = function(n4) {
        this.props.value !== n4.value && u4.some(b);
      }, this.sub = function(n4) {
        u4.push(n4);
        var l4 = n4.componentWillUnmount;
        n4.componentWillUnmount = function() {
          u4.splice(u4.indexOf(n4), 1), l4 && l4.call(n4);
        };
      }), n3.children;
    } };
    return u3.Provider.__ = u3.Consumer.contextType = u3;
  }
  var n, l, u, i, t, o, r, f, e, c;
  var init_preact_module = __esm({
    "node_modules/preact/dist/preact.module.js"() {
      f = {};
      e = [];
      c = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;
      n = e.slice, l = { __e: function(n2, l3, u3, i3) {
        for (var t3, o4, r3; l3 = l3.__; )
          if ((t3 = l3.__c) && !t3.__)
            try {
              if ((o4 = t3.constructor) && null != o4.getDerivedStateFromError && (t3.setState(o4.getDerivedStateFromError(n2)), r3 = t3.__d), null != t3.componentDidCatch && (t3.componentDidCatch(n2, i3 || {}), r3 = t3.__d), r3)
                return t3.__E = t3;
            } catch (l4) {
              n2 = l4;
            }
        throw n2;
      } }, u = 0, i = function(n2) {
        return null != n2 && void 0 === n2.constructor;
      }, d.prototype.setState = function(n2, l3) {
        var u3;
        u3 = null != this.__s && this.__s !== this.state ? this.__s : this.__s = s({}, this.state), "function" == typeof n2 && (n2 = n2(s({}, u3), this.props)), n2 && s(u3, n2), null != n2 && this.__v && (l3 && this._sb.push(l3), b(this));
      }, d.prototype.forceUpdate = function(n2) {
        this.__v && (this.__e = true, n2 && this.__h.push(n2), b(this));
      }, d.prototype.render = p, t = [], g.__r = 0, r = 0;
    }
  });

  // node_modules/preact/hooks/dist/hooks.module.js
  function d2(t3, u3) {
    l.__h && l.__h(r2, t3, o2 || u3), o2 = 0;
    var i3 = r2.__H || (r2.__H = { __: [], __h: [] });
    return t3 >= i3.__.length && i3.__.push({ __V: c2 }), i3.__[t3];
  }
  function p2(n2) {
    return o2 = 1, y2(B2, n2);
  }
  function y2(n2, u3, i3) {
    var o4 = d2(t2++, 2);
    if (o4.t = n2, !o4.__c && (o4.__ = [i3 ? i3(u3) : B2(void 0, u3), function(n3) {
      var t3 = o4.__N ? o4.__N[0] : o4.__[0], r3 = o4.t(t3, n3);
      t3 !== r3 && (o4.__N = [r3, o4.__[1]], o4.__c.setState({}));
    }], o4.__c = r2, !r2.u)) {
      r2.u = true;
      var f3 = r2.shouldComponentUpdate;
      r2.shouldComponentUpdate = function(n3, t3, r3) {
        if (!o4.__c.__H)
          return true;
        var u4 = o4.__c.__H.__.filter(function(n4) {
          return n4.__c;
        });
        if (u4.every(function(n4) {
          return !n4.__N;
        }))
          return !f3 || f3.call(this, n3, t3, r3);
        var i4 = false;
        return u4.forEach(function(n4) {
          if (n4.__N) {
            var t4 = n4.__[0];
            n4.__ = n4.__N, n4.__N = void 0, t4 !== n4.__[0] && (i4 = true);
          }
        }), !(!i4 && o4.__c.props === n3) && (!f3 || f3.call(this, n3, t3, r3));
      };
    }
    return o4.__N || o4.__;
  }
  function h2(u3, i3) {
    var o4 = d2(t2++, 3);
    !l.__s && z2(o4.__H, i3) && (o4.__ = u3, o4.i = i3, r2.__H.__h.push(o4));
  }
  function s2(u3, i3) {
    var o4 = d2(t2++, 4);
    !l.__s && z2(o4.__H, i3) && (o4.__ = u3, o4.i = i3, r2.__h.push(o4));
  }
  function _2(n2) {
    return o2 = 5, F(function() {
      return { current: n2 };
    }, []);
  }
  function A2(n2, t3, r3) {
    o2 = 6, s2(function() {
      return "function" == typeof n2 ? (n2(t3()), function() {
        return n2(null);
      }) : n2 ? (n2.current = t3(), function() {
        return n2.current = null;
      }) : void 0;
    }, null == r3 ? r3 : r3.concat(n2));
  }
  function F(n2, r3) {
    var u3 = d2(t2++, 7);
    return z2(u3.__H, r3) ? (u3.__V = n2(), u3.i = r3, u3.__h = n2, u3.__V) : u3.__;
  }
  function T2(n2, t3) {
    return o2 = 8, F(function() {
      return n2;
    }, t3);
  }
  function q2(n2) {
    var u3 = r2.context[n2.__c], i3 = d2(t2++, 9);
    return i3.c = n2, u3 ? (null == i3.__ && (i3.__ = true, u3.sub(r2)), u3.props.value) : n2.__;
  }
  function x2(t3, r3) {
    l.useDebugValue && l.useDebugValue(r3 ? r3(t3) : t3);
  }
  function P2(n2) {
    var u3 = d2(t2++, 10), i3 = p2();
    return u3.__ = n2, r2.componentDidCatch || (r2.componentDidCatch = function(n3, t3) {
      u3.__ && u3.__(n3, t3), i3[1](n3);
    }), [i3[0], function() {
      i3[1](void 0);
    }];
  }
  function V() {
    var n2 = d2(t2++, 11);
    if (!n2.__) {
      for (var u3 = r2.__v; null !== u3 && !u3.__m && null !== u3.__; )
        u3 = u3.__;
      var i3 = u3.__m || (u3.__m = [0, 0]);
      n2.__ = "P" + i3[0] + "-" + i3[1]++;
    }
    return n2.__;
  }
  function b2() {
    for (var t3; t3 = f2.shift(); )
      if (t3.__P && t3.__H)
        try {
          t3.__H.__h.forEach(k2), t3.__H.__h.forEach(w2), t3.__H.__h = [];
        } catch (r3) {
          t3.__H.__h = [], l.__e(r3, t3.__v);
        }
  }
  function j2(n2) {
    var t3, r3 = function() {
      clearTimeout(u3), g2 && cancelAnimationFrame(t3), setTimeout(n2);
    }, u3 = setTimeout(r3, 100);
    g2 && (t3 = requestAnimationFrame(r3));
  }
  function k2(n2) {
    var t3 = r2, u3 = n2.__c;
    "function" == typeof u3 && (n2.__c = void 0, u3()), r2 = t3;
  }
  function w2(n2) {
    var t3 = r2;
    n2.__c = n2.__(), r2 = t3;
  }
  function z2(n2, t3) {
    return !n2 || n2.length !== t3.length || t3.some(function(t4, r3) {
      return t4 !== n2[r3];
    });
  }
  function B2(n2, t3) {
    return "function" == typeof t3 ? t3(n2) : t3;
  }
  var t2, r2, u2, i2, o2, f2, c2, e2, a2, v2, l2, m2, g2;
  var init_hooks_module = __esm({
    "node_modules/preact/hooks/dist/hooks.module.js"() {
      init_preact_module();
      o2 = 0;
      f2 = [];
      c2 = [];
      e2 = l.__b;
      a2 = l.__r;
      v2 = l.diffed;
      l2 = l.__c;
      m2 = l.unmount;
      l.__b = function(n2) {
        r2 = null, e2 && e2(n2);
      }, l.__r = function(n2) {
        a2 && a2(n2), t2 = 0;
        var i3 = (r2 = n2.__c).__H;
        i3 && (u2 === r2 ? (i3.__h = [], r2.__h = [], i3.__.forEach(function(n3) {
          n3.__N && (n3.__ = n3.__N), n3.__V = c2, n3.__N = n3.i = void 0;
        })) : (i3.__h.forEach(k2), i3.__h.forEach(w2), i3.__h = [])), u2 = r2;
      }, l.diffed = function(t3) {
        v2 && v2(t3);
        var o4 = t3.__c;
        o4 && o4.__H && (o4.__H.__h.length && (1 !== f2.push(o4) && i2 === l.requestAnimationFrame || ((i2 = l.requestAnimationFrame) || j2)(b2)), o4.__H.__.forEach(function(n2) {
          n2.i && (n2.__H = n2.i), n2.__V !== c2 && (n2.__ = n2.__V), n2.i = void 0, n2.__V = c2;
        })), u2 = r2 = null;
      }, l.__c = function(t3, r3) {
        r3.some(function(t4) {
          try {
            t4.__h.forEach(k2), t4.__h = t4.__h.filter(function(n2) {
              return !n2.__ || w2(n2);
            });
          } catch (u3) {
            r3.some(function(n2) {
              n2.__h && (n2.__h = []);
            }), r3 = [], l.__e(u3, t4.__v);
          }
        }), l2 && l2(t3, r3);
      }, l.unmount = function(t3) {
        m2 && m2(t3);
        var r3, u3 = t3.__c;
        u3 && u3.__H && (u3.__H.__.forEach(function(n2) {
          try {
            k2(n2);
          } catch (n3) {
            r3 = n3;
          }
        }), u3.__H = void 0, r3 && l.__e(r3, u3.__v));
      };
      g2 = "function" == typeof requestAnimationFrame;
    }
  });

  // node_modules/preact/compat/dist/compat.module.js
  function g3(n2, t3) {
    for (var e3 in t3)
      n2[e3] = t3[e3];
    return n2;
  }
  function C2(n2, t3) {
    for (var e3 in n2)
      if ("__source" !== e3 && !(e3 in t3))
        return true;
    for (var r3 in t3)
      if ("__source" !== r3 && n2[r3] !== t3[r3])
        return true;
    return false;
  }
  function E(n2, t3) {
    return n2 === t3 && (0 !== n2 || 1 / n2 == 1 / t3) || n2 != n2 && t3 != t3;
  }
  function w3(n2) {
    this.props = n2;
  }
  function R(n2, e3) {
    function r3(n3) {
      var t3 = this.props.ref, r4 = t3 == n3.ref;
      return !r4 && t3 && (t3.call ? t3(null) : t3.current = null), e3 ? !e3(this.props, n3) || !r4 : C2(this.props, n3);
    }
    function u3(e4) {
      return this.shouldComponentUpdate = r3, h(n2, e4);
    }
    return u3.displayName = "Memo(" + (n2.displayName || n2.name) + ")", u3.prototype.isReactComponent = true, u3.__f = true, u3;
  }
  function k3(n2) {
    function t3(t4) {
      var e3 = g3({}, t4);
      return delete e3.ref, n2(e3, t4.ref || null);
    }
    return t3.$$typeof = N2, t3.render = t3, t3.prototype.isReactComponent = t3.__f = true, t3.displayName = "ForwardRef(" + (n2.displayName || n2.name) + ")", t3;
  }
  function L2(n2, t3, e3) {
    return n2 && (n2.__c && n2.__c.__H && (n2.__c.__H.__.forEach(function(n3) {
      "function" == typeof n3.__c && n3.__c();
    }), n2.__c.__H = null), null != (n2 = g3({}, n2)).__c && (n2.__c.__P === e3 && (n2.__c.__P = t3), n2.__c = null), n2.__k = n2.__k && n2.__k.map(function(n3) {
      return L2(n3, t3, e3);
    })), n2;
  }
  function U(n2, t3, e3) {
    return n2 && (n2.__v = null, n2.__k = n2.__k && n2.__k.map(function(n3) {
      return U(n3, t3, e3);
    }), n2.__c && n2.__c.__P === t3 && (n2.__e && e3.insertBefore(n2.__e, n2.__d), n2.__c.__e = true, n2.__c.__P = e3)), n2;
  }
  function D() {
    this.__u = 0, this.t = null, this.__b = null;
  }
  function F2(n2) {
    var t3 = n2.__.__c;
    return t3 && t3.__a && t3.__a(n2);
  }
  function M2(n2) {
    var e3, r3, u3;
    function o4(o5) {
      if (e3 || (e3 = n2()).then(function(n3) {
        r3 = n3.default || n3;
      }, function(n3) {
        u3 = n3;
      }), u3)
        throw u3;
      if (!r3)
        throw e3;
      return h(r3, o5);
    }
    return o4.displayName = "Lazy", o4.__f = true, o4;
  }
  function V2() {
    this.u = null, this.o = null;
  }
  function P3(n2) {
    return this.getChildContext = function() {
      return n2.context;
    }, n2.children;
  }
  function $2(n2) {
    var e3 = this, r3 = n2.i;
    e3.componentWillUnmount = function() {
      P(null, e3.l), e3.l = null, e3.i = null;
    }, e3.i && e3.i !== r3 && e3.componentWillUnmount(), n2.__v ? (e3.l || (e3.i = r3, e3.l = { nodeType: 1, parentNode: r3, childNodes: [], appendChild: function(n3) {
      this.childNodes.push(n3), e3.i.appendChild(n3);
    }, insertBefore: function(n3, t3) {
      this.childNodes.push(n3), e3.i.appendChild(n3);
    }, removeChild: function(n3) {
      this.childNodes.splice(this.childNodes.indexOf(n3) >>> 1, 1), e3.i.removeChild(n3);
    } }), P(h(P3, { context: e3.context }, n2.__v), e3.l)) : e3.l && e3.componentWillUnmount();
  }
  function j3(n2, e3) {
    var r3 = h($2, { __v: n2, i: e3 });
    return r3.containerInfo = e3, r3;
  }
  function Y(n2, t3, e3) {
    return null == t3.__k && (t3.textContent = ""), P(n2, t3), "function" == typeof e3 && e3(), n2 ? n2.__c : null;
  }
  function q3(n2, t3, e3) {
    return S(n2, t3), "function" == typeof e3 && e3(), n2 ? n2.__c : null;
  }
  function J() {
  }
  function K() {
    return this.cancelBubble;
  }
  function Q() {
    return this.defaultPrevented;
  }
  function on(n2) {
    return h.bind(null, n2);
  }
  function ln(n2) {
    return !!n2 && n2.$$typeof === z3;
  }
  function cn(n2) {
    return ln(n2) ? q.apply(null, arguments) : n2;
  }
  function fn(n2) {
    return !!n2.__k && (P(null, n2), true);
  }
  function an(n2) {
    return n2 && (n2.base || 1 === n2.nodeType && n2) || null;
  }
  function dn(n2) {
    n2();
  }
  function pn(n2) {
    return n2;
  }
  function mn() {
    return [false, dn];
  }
  function _n(n2, t3) {
    var e3 = t3(), r3 = p2({ h: { __: e3, v: t3 } }), u3 = r3[0].h, o4 = r3[1];
    return s2(function() {
      u3.__ = e3, u3.v = t3, E(u3.__, t3()) || o4({ h: u3 });
    }, [n2, e3, t3]), h2(function() {
      return E(u3.__, u3.v()) || o4({ h: u3 }), n2(function() {
        E(u3.__, u3.v()) || o4({ h: u3 });
      });
    }, [n2]), e3;
  }
  var x3, N2, A3, O2, T3, I2, W, z3, B3, H2, Z, G, X, nn, tn, en, rn, un, sn, hn, vn, yn, bn;
  var init_compat_module = __esm({
    "node_modules/preact/compat/dist/compat.module.js"() {
      init_preact_module();
      init_preact_module();
      init_hooks_module();
      init_hooks_module();
      (w3.prototype = new d()).isPureReactComponent = true, w3.prototype.shouldComponentUpdate = function(n2, t3) {
        return C2(this.props, n2) || C2(this.state, t3);
      };
      x3 = l.__b;
      l.__b = function(n2) {
        n2.type && n2.type.__f && n2.ref && (n2.props.ref = n2.ref, n2.ref = null), x3 && x3(n2);
      };
      N2 = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.forward_ref") || 3911;
      A3 = function(n2, t3) {
        return null == n2 ? null : x(x(n2).map(t3));
      };
      O2 = { map: A3, forEach: A3, count: function(n2) {
        return n2 ? x(n2).length : 0;
      }, only: function(n2) {
        var t3 = x(n2);
        if (1 !== t3.length)
          throw "Children.only";
        return t3[0];
      }, toArray: x };
      T3 = l.__e;
      l.__e = function(n2, t3, e3, r3) {
        if (n2.then) {
          for (var u3, o4 = t3; o4 = o4.__; )
            if ((u3 = o4.__c) && u3.__c)
              return null == t3.__e && (t3.__e = e3.__e, t3.__k = e3.__k), u3.__c(n2, t3);
        }
        T3(n2, t3, e3, r3);
      };
      I2 = l.unmount;
      l.unmount = function(n2) {
        var t3 = n2.__c;
        t3 && t3.__R && t3.__R(), t3 && true === n2.__h && (n2.type = null), I2 && I2(n2);
      }, (D.prototype = new d()).__c = function(n2, t3) {
        var e3 = t3.__c, r3 = this;
        null == r3.t && (r3.t = []), r3.t.push(e3);
        var u3 = F2(r3.__v), o4 = false, i3 = function() {
          o4 || (o4 = true, e3.__R = null, u3 ? u3(l3) : l3());
        };
        e3.__R = i3;
        var l3 = function() {
          if (!--r3.__u) {
            if (r3.state.__a) {
              var n3 = r3.state.__a;
              r3.__v.__k[0] = U(n3, n3.__c.__P, n3.__c.__O);
            }
            var t4;
            for (r3.setState({ __a: r3.__b = null }); t4 = r3.t.pop(); )
              t4.forceUpdate();
          }
        }, c3 = true === t3.__h;
        r3.__u++ || c3 || r3.setState({ __a: r3.__b = r3.__v.__k[0] }), n2.then(i3, i3);
      }, D.prototype.componentWillUnmount = function() {
        this.t = [];
      }, D.prototype.render = function(n2, e3) {
        if (this.__b) {
          if (this.__v.__k) {
            var r3 = document.createElement("div"), o4 = this.__v.__k[0].__c;
            this.__v.__k[0] = L2(this.__b, r3, o4.__O = o4.__P);
          }
          this.__b = null;
        }
        var i3 = e3.__a && h(p, null, n2.fallback);
        return i3 && (i3.__h = null), [h(p, null, e3.__a ? null : n2.children), i3];
      };
      W = function(n2, t3, e3) {
        if (++e3[1] === e3[0] && n2.o.delete(t3), n2.props.revealOrder && ("t" !== n2.props.revealOrder[0] || !n2.o.size))
          for (e3 = n2.u; e3; ) {
            for (; e3.length > 3; )
              e3.pop()();
            if (e3[1] < e3[0])
              break;
            n2.u = e3 = e3[2];
          }
      };
      (V2.prototype = new d()).__a = function(n2) {
        var t3 = this, e3 = F2(t3.__v), r3 = t3.o.get(n2);
        return r3[0]++, function(u3) {
          var o4 = function() {
            t3.props.revealOrder ? (r3.push(u3), W(t3, n2, r3)) : u3();
          };
          e3 ? e3(o4) : o4();
        };
      }, V2.prototype.render = function(n2) {
        this.u = null, this.o = /* @__PURE__ */ new Map();
        var t3 = x(n2.children);
        n2.revealOrder && "b" === n2.revealOrder[0] && t3.reverse();
        for (var e3 = t3.length; e3--; )
          this.o.set(t3[e3], this.u = [1, 0, this.u]);
        return n2.children;
      }, V2.prototype.componentDidUpdate = V2.prototype.componentDidMount = function() {
        var n2 = this;
        this.o.forEach(function(t3, e3) {
          W(n2, e3, t3);
        });
      };
      z3 = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103;
      B3 = /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/;
      H2 = "undefined" != typeof document;
      Z = function(n2) {
        return ("undefined" != typeof Symbol && "symbol" == typeof Symbol() ? /fil|che|rad/i : /fil|che|ra/i).test(n2);
      };
      d.prototype.isReactComponent = {}, ["componentWillMount", "componentWillReceiveProps", "componentWillUpdate"].forEach(function(t3) {
        Object.defineProperty(d.prototype, t3, { configurable: true, get: function() {
          return this["UNSAFE_" + t3];
        }, set: function(n2) {
          Object.defineProperty(this, t3, { configurable: true, writable: true, value: n2 });
        } });
      });
      G = l.event;
      l.event = function(n2) {
        return G && (n2 = G(n2)), n2.persist = J, n2.isPropagationStopped = K, n2.isDefaultPrevented = Q, n2.nativeEvent = n2;
      };
      nn = { configurable: true, get: function() {
        return this.class;
      } };
      tn = l.vnode;
      l.vnode = function(n2) {
        var t3 = n2.type, e3 = n2.props, u3 = e3;
        if ("string" == typeof t3) {
          var o4 = -1 === t3.indexOf("-");
          for (var i3 in u3 = {}, e3) {
            var l3 = e3[i3];
            H2 && "children" === i3 && "noscript" === t3 || "value" === i3 && "defaultValue" in e3 && null == l3 || ("defaultValue" === i3 && "value" in e3 && null == e3.value ? i3 = "value" : "download" === i3 && true === l3 ? l3 = "" : /ondoubleclick/i.test(i3) ? i3 = "ondblclick" : /^onchange(textarea|input)/i.test(i3 + t3) && !Z(e3.type) ? i3 = "oninput" : /^onfocus$/i.test(i3) ? i3 = "onfocusin" : /^onblur$/i.test(i3) ? i3 = "onfocusout" : /^on(Ani|Tra|Tou|BeforeInp|Compo)/.test(i3) ? i3 = i3.toLowerCase() : o4 && B3.test(i3) ? i3 = i3.replace(/[A-Z0-9]/g, "-$&").toLowerCase() : null === l3 && (l3 = void 0), /^oninput$/i.test(i3) && (i3 = i3.toLowerCase(), u3[i3] && (i3 = "oninputCapture")), u3[i3] = l3);
          }
          "select" == t3 && u3.multiple && Array.isArray(u3.value) && (u3.value = x(e3.children).forEach(function(n3) {
            n3.props.selected = -1 != u3.value.indexOf(n3.props.value);
          })), "select" == t3 && null != u3.defaultValue && (u3.value = x(e3.children).forEach(function(n3) {
            n3.props.selected = u3.multiple ? -1 != u3.defaultValue.indexOf(n3.props.value) : u3.defaultValue == n3.props.value;
          })), n2.props = u3, e3.class != e3.className && (nn.enumerable = "className" in e3, null != e3.className && (u3.class = e3.className), Object.defineProperty(u3, "className", nn));
        }
        n2.$$typeof = z3, tn && tn(n2);
      };
      en = l.__r;
      l.__r = function(n2) {
        en && en(n2), X = n2.__c;
      };
      rn = { ReactCurrentDispatcher: { current: { readContext: function(n2) {
        return X.__n[n2.__c].props.value;
      } } } };
      un = "17.0.2";
      sn = function(n2, t3) {
        return n2(t3);
      };
      hn = function(n2, t3) {
        return n2(t3);
      };
      vn = p;
      yn = s2;
      bn = { useState: p2, useId: V, useReducer: y2, useEffect: h2, useLayoutEffect: s2, useInsertionEffect: yn, useTransition: mn, useDeferredValue: pn, useSyncExternalStore: _n, startTransition: dn, useRef: _2, useImperativeHandle: A2, useMemo: F, useCallback: T2, useContext: q2, useDebugValue: x2, version: "17.0.2", Children: O2, render: Y, hydrate: q3, unmountComponentAtNode: fn, createPortal: j3, createElement: h, createContext: B, createFactory: on, cloneElement: cn, createRef: y, Fragment: p, isValidElement: ln, findDOMNode: an, Component: d, PureComponent: w3, memo: R, forwardRef: k3, flushSync: hn, unstable_batchedUpdates: sn, StrictMode: vn, Suspense: D, SuspenseList: V2, lazy: M2, __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: rn };
    }
  });

  // node_modules/react/index.mjs
  var react_exports = {};
  __export(react_exports, {
    Children: () => O2,
    Component: () => d,
    Fragment: () => p,
    PureComponent: () => w3,
    StrictMode: () => vn,
    Suspense: () => D,
    SuspenseList: () => V2,
    __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: () => rn,
    cloneElement: () => cn,
    createContext: () => B,
    createElement: () => h,
    createFactory: () => on,
    createPortal: () => j3,
    createRef: () => y,
    default: () => bn,
    findDOMNode: () => an,
    flushSync: () => hn,
    forwardRef: () => k3,
    hydrate: () => q3,
    isValidElement: () => ln,
    lazy: () => M2,
    memo: () => R,
    render: () => Y,
    startTransition: () => dn,
    unmountComponentAtNode: () => fn,
    unstable_batchedUpdates: () => sn,
    useCallback: () => T2,
    useContext: () => q2,
    useDebugValue: () => x2,
    useDeferredValue: () => pn,
    useEffect: () => h2,
    useErrorBoundary: () => P2,
    useId: () => V,
    useImperativeHandle: () => A2,
    useInsertionEffect: () => yn,
    useLayoutEffect: () => s2,
    useMemo: () => F,
    useReducer: () => y2,
    useRef: () => _2,
    useState: () => p2,
    useSyncExternalStore: () => _n,
    useTransition: () => mn,
    version: () => un
  });
  var init_react = __esm({
    "node_modules/react/index.mjs"() {
      init_compat_module();
      init_compat_module();
    }
  });

  // node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.production.min.js
  var require_use_sync_external_store_shim_production_min = __commonJS({
    "node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.production.min.js"(exports) {
      "use strict";
      var e3 = (init_react(), __toCommonJS(react_exports));
      function h3(a3, b3) {
        return a3 === b3 && (0 !== a3 || 1 / a3 === 1 / b3) || a3 !== a3 && b3 !== b3;
      }
      var k4 = "function" === typeof Object.is ? Object.is : h3;
      var l3 = e3.useState;
      var m3 = e3.useEffect;
      var n2 = e3.useLayoutEffect;
      var p3 = e3.useDebugValue;
      function q4(a3, b3) {
        var d3 = b3(), f3 = l3({ inst: { value: d3, getSnapshot: b3 } }), c3 = f3[0].inst, g4 = f3[1];
        n2(function() {
          c3.value = d3;
          c3.getSnapshot = b3;
          r3(c3) && g4({ inst: c3 });
        }, [a3, d3, b3]);
        m3(function() {
          r3(c3) && g4({ inst: c3 });
          return a3(function() {
            r3(c3) && g4({ inst: c3 });
          });
        }, [a3]);
        p3(d3);
        return d3;
      }
      function r3(a3) {
        var b3 = a3.getSnapshot;
        a3 = a3.value;
        try {
          var d3 = b3();
          return !k4(a3, d3);
        } catch (f3) {
          return true;
        }
      }
      function t3(a3, b3) {
        return b3();
      }
      var u3 = "undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? t3 : q4;
      exports.useSyncExternalStore = void 0 !== e3.useSyncExternalStore ? e3.useSyncExternalStore : u3;
    }
  });

  // node_modules/use-sync-external-store/shim/index.js
  var require_shim = __commonJS({
    "node_modules/use-sync-external-store/shim/index.js"(exports, module) {
      "use strict";
      if (true) {
        module.exports = require_use_sync_external_store_shim_production_min();
      } else {
        module.exports = null;
      }
    }
  });

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!globalThis.chrome?.runtime?.id) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (typeof globalThis.browser === "undefined" || Object.getPrototypeOf(globalThis.browser) !== Object.prototype) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache2 = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache2;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache2) {
                    return cache2[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache2, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache2[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache2) {
                    cache2[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache2, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache2, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(
                  req,
                  {},
                  {
                    getContent: {
                      minArgs: 0,
                      maxArgs: 0
                    }
                  }
                );
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/popup/index.tsx
  init_preact_module();

  // node_modules/@primer/octicons-react/dist/index.esm.js
  init_react();
  var sizeMap = {
    small: 16,
    medium: 32,
    large: 64
  };
  function createIconComponent(name, defaultClassName, getSVGData) {
    var svgDataByHeight = getSVGData();
    var heights = Object.keys(svgDataByHeight);
    function Icon(_ref) {
      var ariaLabel = _ref["aria-label"], tabIndex = _ref.tabIndex, className = _ref.className, _ref$fill = _ref.fill, fill = _ref$fill === void 0 ? "currentColor" : _ref$fill, size = _ref.size, verticalAlign = _ref.verticalAlign;
      var height = sizeMap[size] || size;
      var naturalHeight = closestNaturalHeight(heights, height);
      var naturalWidth = svgDataByHeight[naturalHeight].width;
      var width = height * (naturalWidth / naturalHeight);
      var path = svgDataByHeight[naturalHeight].path;
      return /* @__PURE__ */ bn.createElement("svg", {
        "aria-hidden": ariaLabel ? "false" : "true",
        tabIndex,
        focusable: tabIndex >= 0 ? "true" : "false",
        "aria-label": ariaLabel,
        role: "img",
        className,
        viewBox: "0 0 ".concat(naturalWidth, " ").concat(naturalHeight),
        width,
        height,
        fill,
        style: {
          display: "inline-block",
          userSelect: "none",
          verticalAlign,
          overflow: "visible"
        }
      }, path);
    }
    Icon.displayName = name;
    Icon.defaultProps = {
      className: defaultClassName,
      size: 16,
      verticalAlign: "text-bottom"
    };
    return Icon;
  }
  function closestNaturalHeight(naturalHeights, height) {
    return naturalHeights.map(function(naturalHeight) {
      return parseInt(naturalHeight, 10);
    }).reduce(function(acc, naturalHeight) {
      return naturalHeight <= height ? naturalHeight : acc;
    }, naturalHeights[0]);
  }
  var GearIcon = /* @__PURE__ */ createIconComponent("GearIcon", "octicon octicon-gear", function() {
    return {
      "16": {
        "width": 16,
        "path": /* @__PURE__ */ bn.createElement("path", {
          fillRule: "evenodd",
          d: "M7.429 1.525a6.593 6.593 0 011.142 0c.036.003.108.036.137.146l.289 1.105c.147.56.55.967.997 1.189.174.086.341.183.501.29.417.278.97.423 1.53.27l1.102-.303c.11-.03.175.016.195.046.219.31.41.641.573.989.014.031.022.11-.059.19l-.815.806c-.411.406-.562.957-.53 1.456a4.588 4.588 0 010 .582c-.032.499.119 1.05.53 1.456l.815.806c.08.08.073.159.059.19a6.494 6.494 0 01-.573.99c-.02.029-.086.074-.195.045l-1.103-.303c-.559-.153-1.112-.008-1.529.27-.16.107-.327.204-.5.29-.449.222-.851.628-.998 1.189l-.289 1.105c-.029.11-.101.143-.137.146a6.613 6.613 0 01-1.142 0c-.036-.003-.108-.037-.137-.146l-.289-1.105c-.147-.56-.55-.967-.997-1.189a4.502 4.502 0 01-.501-.29c-.417-.278-.97-.423-1.53-.27l-1.102.303c-.11.03-.175-.016-.195-.046a6.492 6.492 0 01-.573-.989c-.014-.031-.022-.11.059-.19l.815-.806c.411-.406.562-.957.53-1.456a4.587 4.587 0 010-.582c.032-.499-.119-1.05-.53-1.456l-.815-.806c-.08-.08-.073-.159-.059-.19a6.44 6.44 0 01.573-.99c.02-.029.086-.075.195-.045l1.103.303c.559.153 1.112.008 1.529-.27.16-.107.327-.204.5-.29.449-.222.851-.628.998-1.189l.289-1.105c.029-.11.101-.143.137-.146zM8 0c-.236 0-.47.01-.701.03-.743.065-1.29.615-1.458 1.261l-.29 1.106c-.017.066-.078.158-.211.224a5.994 5.994 0 00-.668.386c-.123.082-.233.09-.3.071L3.27 2.776c-.644-.177-1.392.02-1.82.63a7.977 7.977 0 00-.704 1.217c-.315.675-.111 1.422.363 1.891l.815.806c.05.048.098.147.088.294a6.084 6.084 0 000 .772c.01.147-.038.246-.088.294l-.815.806c-.474.469-.678 1.216-.363 1.891.2.428.436.835.704 1.218.428.609 1.176.806 1.82.63l1.103-.303c.066-.019.176-.011.299.071.213.143.436.272.668.386.133.066.194.158.212.224l.289 1.106c.169.646.715 1.196 1.458 1.26a8.094 8.094 0 001.402 0c.743-.064 1.29-.614 1.458-1.26l.29-1.106c.017-.066.078-.158.211-.224a5.98 5.98 0 00.668-.386c.123-.082.233-.09.3-.071l1.102.302c.644.177 1.392-.02 1.82-.63.268-.382.505-.789.704-1.217.315-.675.111-1.422-.364-1.891l-.814-.806c-.05-.048-.098-.147-.088-.294a6.1 6.1 0 000-.772c-.01-.147.039-.246.088-.294l.814-.806c.475-.469.679-1.216.364-1.891a7.992 7.992 0 00-.704-1.218c-.428-.609-1.176-.806-1.82-.63l-1.103.303c-.066.019-.176.011-.299-.071a5.991 5.991 0 00-.668-.386c-.133-.066-.194-.158-.212-.224L10.16 1.29C9.99.645 9.444.095 8.701.031A8.094 8.094 0 008 0zm1.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM11 8a3 3 0 11-6 0 3 3 0 016 0z"
        })
      },
      "24": {
        "width": 24,
        "path": /* @__PURE__ */ bn.createElement(bn.Fragment, null, /* @__PURE__ */ bn.createElement("path", {
          fillRule: "evenodd",
          d: "M16 12a4 4 0 11-8 0 4 4 0 018 0zm-1.5 0a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"
        }), /* @__PURE__ */ bn.createElement("path", {
          fillRule: "evenodd",
          d: "M12 1c-.268 0-.534.01-.797.028-.763.055-1.345.617-1.512 1.304l-.352 1.45c-.02.078-.09.172-.225.22a8.45 8.45 0 00-.728.303c-.13.06-.246.044-.315.002l-1.274-.776c-.604-.368-1.412-.354-1.99.147-.403.348-.78.726-1.129 1.128-.5.579-.515 1.387-.147 1.99l.776 1.275c.042.069.059.185-.002.315-.112.237-.213.48-.302.728-.05.135-.143.206-.221.225l-1.45.352c-.687.167-1.249.749-1.304 1.512a11.149 11.149 0 000 1.594c.055.763.617 1.345 1.304 1.512l1.45.352c.078.02.172.09.22.225.09.248.191.491.303.729.06.129.044.245.002.314l-.776 1.274c-.368.604-.354 1.412.147 1.99.348.403.726.78 1.128 1.129.579.5 1.387.515 1.99.147l1.275-.776c.069-.042.185-.059.315.002.237.112.48.213.728.302.135.05.206.143.225.221l.352 1.45c.167.687.749 1.249 1.512 1.303a11.125 11.125 0 001.594 0c.763-.054 1.345-.616 1.512-1.303l.352-1.45c.02-.078.09-.172.225-.22.248-.09.491-.191.729-.303.129-.06.245-.044.314-.002l1.274.776c.604.368 1.412.354 1.99-.147.403-.348.78-.726 1.129-1.128.5-.579.515-1.387.147-1.99l-.776-1.275c-.042-.069-.059-.185.002-.315.112-.237.213-.48.302-.728.05-.135.143-.206.221-.225l1.45-.352c.687-.167 1.249-.749 1.303-1.512a11.125 11.125 0 000-1.594c-.054-.763-.616-1.345-1.303-1.512l-1.45-.352c-.078-.02-.172-.09-.22-.225a8.469 8.469 0 00-.303-.728c-.06-.13-.044-.246-.002-.315l.776-1.274c.368-.604.354-1.412-.147-1.99-.348-.403-.726-.78-1.128-1.129-.579-.5-1.387-.515-1.99-.147l-1.275.776c-.069.042-.185.059-.315-.002a8.465 8.465 0 00-.728-.302c-.135-.05-.206-.143-.225-.221l-.352-1.45c-.167-.687-.749-1.249-1.512-1.304A11.149 11.149 0 0012 1zm-.69 1.525a9.648 9.648 0 011.38 0c.055.004.135.05.162.16l.351 1.45c.153.628.626 1.08 1.173 1.278.205.074.405.157.6.249a1.832 1.832 0 001.733-.074l1.275-.776c.097-.06.186-.036.228 0 .348.302.674.628.976.976.036.042.06.13 0 .228l-.776 1.274a1.832 1.832 0 00-.074 1.734c.092.195.175.395.248.6.198.547.652 1.02 1.278 1.172l1.45.353c.111.026.157.106.161.161a9.653 9.653 0 010 1.38c-.004.055-.05.135-.16.162l-1.45.351a1.833 1.833 0 00-1.278 1.173 6.926 6.926 0 01-.25.6 1.832 1.832 0 00.075 1.733l.776 1.275c.06.097.036.186 0 .228a9.555 9.555 0 01-.976.976c-.042.036-.13.06-.228 0l-1.275-.776a1.832 1.832 0 00-1.733-.074 6.926 6.926 0 01-.6.248 1.833 1.833 0 00-1.172 1.278l-.353 1.45c-.026.111-.106.157-.161.161a9.653 9.653 0 01-1.38 0c-.055-.004-.135-.05-.162-.16l-.351-1.45a1.833 1.833 0 00-1.173-1.278 6.928 6.928 0 01-.6-.25 1.832 1.832 0 00-1.734.075l-1.274.776c-.097.06-.186.036-.228 0a9.56 9.56 0 01-.976-.976c-.036-.042-.06-.13 0-.228l.776-1.275a1.832 1.832 0 00.074-1.733 6.948 6.948 0 01-.249-.6 1.833 1.833 0 00-1.277-1.172l-1.45-.353c-.111-.026-.157-.106-.161-.161a9.648 9.648 0 010-1.38c.004-.055.05-.135.16-.162l1.45-.351a1.833 1.833 0 001.278-1.173 6.95 6.95 0 01.249-.6 1.832 1.832 0 00-.074-1.734l-.776-1.274c-.06-.097-.036-.186 0-.228.302-.348.628-.674.976-.976.042-.036.13-.06.228 0l1.274.776a1.832 1.832 0 001.734.074 6.95 6.95 0 01.6-.249 1.833 1.833 0 001.172-1.277l.353-1.45c.026-.111.106-.157.161-.161z"
        }))
      }
    };
  });
  var GlobeIcon = /* @__PURE__ */ createIconComponent("GlobeIcon", "octicon octicon-globe", function() {
    return {
      "16": {
        "width": 16,
        "path": /* @__PURE__ */ bn.createElement("path", {
          fillRule: "evenodd",
          d: "M1.543 7.25h2.733c.144-2.074.866-3.756 1.58-4.948.12-.197.237-.381.353-.552a6.506 6.506 0 00-4.666 5.5zm2.733 1.5H1.543a6.506 6.506 0 004.666 5.5 11.13 11.13 0 01-.352-.552c-.715-1.192-1.437-2.874-1.581-4.948zm1.504 0h4.44a9.637 9.637 0 01-1.363 4.177c-.306.51-.612.919-.857 1.215a9.978 9.978 0 01-.857-1.215A9.637 9.637 0 015.78 8.75zm4.44-1.5H5.78a9.637 9.637 0 011.363-4.177c.306-.51.612-.919.857-1.215.245.296.55.705.857 1.215A9.638 9.638 0 0110.22 7.25zm1.504 1.5c-.144 2.074-.866 3.756-1.58 4.948-.12.197-.237.381-.353.552a6.506 6.506 0 004.666-5.5h-2.733zm2.733-1.5h-2.733c-.144-2.074-.866-3.756-1.58-4.948a11.738 11.738 0 00-.353-.552 6.506 6.506 0 014.666 5.5zM8 0a8 8 0 100 16A8 8 0 008 0z"
        })
      },
      "24": {
        "width": 24,
        "path": /* @__PURE__ */ bn.createElement("path", {
          fillRule: "evenodd",
          d: "M12 1C5.925 1 1 5.925 1 12s4.925 11 11 11 11-4.925 11-11S18.075 1 12 1zM2.513 11.5h4.745c.1-3.037 1.1-5.49 2.093-7.204.39-.672.78-1.233 1.119-1.673C6.11 3.329 2.746 7 2.513 11.5zm4.77 1.5H2.552a9.505 9.505 0 007.918 8.377 15.698 15.698 0 01-1.119-1.673C8.413 18.085 7.47 15.807 7.283 13zm1.504 0h6.426c-.183 2.48-1.02 4.5-1.862 5.951-.476.82-.95 1.455-1.304 1.88L12 20.89l-.047-.057a13.888 13.888 0 01-1.304-1.88C9.807 17.5 8.969 15.478 8.787 13zm6.454-1.5H8.759c.1-2.708.992-4.904 1.89-6.451.476-.82.95-1.455 1.304-1.88L12 3.11l.047.057c.353.426.828 1.06 1.304 1.88.898 1.548 1.79 3.744 1.89 6.452zm1.476 1.5c-.186 2.807-1.13 5.085-2.068 6.704-.39.672-.78 1.233-1.118 1.673A9.505 9.505 0 0021.447 13h-4.731zm4.77-1.5h-4.745c-.1-3.037-1.1-5.49-2.093-7.204-.39-.672-.78-1.233-1.119-1.673 4.36.706 7.724 4.377 7.957 8.877z"
        })
      }
    };
  });

  // src/popup/App.tsx
  init_react();

  // node_modules/swr/core/dist/index.mjs
  init_react();
  var import_shim = __toESM(require_shim(), 1);

  // node_modules/swr/_internal/dist/index.mjs
  init_react();
  var SWRGlobalState = /* @__PURE__ */ new WeakMap();
  var EMPTY_CACHE = {};
  var noop = () => {
  };
  var UNDEFINED = (
    /*#__NOINLINE__*/
    noop()
  );
  var OBJECT = Object;
  var isUndefined = (v3) => v3 === UNDEFINED;
  var isFunction = (v3) => typeof v3 == "function";
  var mergeObjects = (a3, b3) => ({
    ...a3,
    ...b3
  });
  var STR_UNDEFINED = "undefined";
  var isWindowDefined = typeof window != STR_UNDEFINED;
  var isDocumentDefined = typeof document != STR_UNDEFINED;
  var hasRequestAnimationFrame = () => isWindowDefined && typeof window["requestAnimationFrame"] != STR_UNDEFINED;
  var createCacheHelper = (cache2, key) => {
    const state = SWRGlobalState.get(cache2);
    return [
      // Getter
      () => cache2.get(key) || EMPTY_CACHE,
      // Setter
      (info) => {
        const prev = cache2.get(key);
        state[5](key, mergeObjects(prev, info), prev || EMPTY_CACHE);
      },
      // Subscriber
      state[6]
    ];
  };
  var table = /* @__PURE__ */ new WeakMap();
  var counter = 0;
  var stableHash = (arg) => {
    const type = typeof arg;
    const constructor = arg && arg.constructor;
    const isDate = constructor == Date;
    let result;
    let index;
    if (OBJECT(arg) === arg && !isDate && constructor != RegExp) {
      result = table.get(arg);
      if (result)
        return result;
      result = ++counter + "~";
      table.set(arg, result);
      if (constructor == Array) {
        result = "@";
        for (index = 0; index < arg.length; index++) {
          result += stableHash(arg[index]) + ",";
        }
        table.set(arg, result);
      }
      if (constructor == OBJECT) {
        result = "#";
        const keys = OBJECT.keys(arg).sort();
        while (!isUndefined(index = keys.pop())) {
          if (!isUndefined(arg[index])) {
            result += index + ":" + stableHash(arg[index]) + ",";
          }
        }
        table.set(arg, result);
      }
    } else {
      result = isDate ? arg.toJSON() : type == "symbol" ? arg.toString() : type == "string" ? JSON.stringify(arg) : "" + arg;
    }
    return result;
  };
  var online = true;
  var isOnline = () => online;
  var [onWindowEvent, offWindowEvent] = isWindowDefined && window.addEventListener ? [
    window.addEventListener.bind(window),
    window.removeEventListener.bind(window)
  ] : [
    noop,
    noop
  ];
  var isVisible = () => {
    const visibilityState = isDocumentDefined && document.visibilityState;
    return isUndefined(visibilityState) || visibilityState !== "hidden";
  };
  var initFocus = (callback) => {
    if (isDocumentDefined) {
      document.addEventListener("visibilitychange", callback);
    }
    onWindowEvent("focus", callback);
    return () => {
      if (isDocumentDefined) {
        document.removeEventListener("visibilitychange", callback);
      }
      offWindowEvent("focus", callback);
    };
  };
  var initReconnect = (callback) => {
    const onOnline = () => {
      online = true;
      callback();
    };
    const onOffline = () => {
      online = false;
    };
    onWindowEvent("online", onOnline);
    onWindowEvent("offline", onOffline);
    return () => {
      offWindowEvent("online", onOnline);
      offWindowEvent("offline", onOffline);
    };
  };
  var preset = {
    isOnline,
    isVisible
  };
  var defaultConfigOptions = {
    initFocus,
    initReconnect
  };
  var IS_REACT_LEGACY = !bn.useId;
  var IS_SERVER = !isWindowDefined || "Deno" in window;
  var rAF = (f3) => hasRequestAnimationFrame() ? window["requestAnimationFrame"](f3) : setTimeout(f3, 1);
  var useIsomorphicLayoutEffect = IS_SERVER ? h2 : s2;
  var navigatorConnection = typeof navigator !== "undefined" && navigator.connection;
  var slowConnection = !IS_SERVER && navigatorConnection && ([
    "slow-2g",
    "2g"
  ].includes(navigatorConnection.effectiveType) || navigatorConnection.saveData);
  var serialize = (key) => {
    if (isFunction(key)) {
      try {
        key = key();
      } catch (err) {
        key = "";
      }
    }
    const args = key;
    key = typeof key == "string" ? key : (Array.isArray(key) ? key.length : key) ? stableHash(key) : "";
    return [
      key,
      args
    ];
  };
  var __timestamp = 0;
  var getTimestamp = () => ++__timestamp;
  var FOCUS_EVENT = 0;
  var RECONNECT_EVENT = 1;
  var MUTATE_EVENT = 2;
  var constants = {
    __proto__: null,
    FOCUS_EVENT,
    RECONNECT_EVENT,
    MUTATE_EVENT
  };
  async function internalMutate(...args) {
    const [cache2, _key, _data, _opts] = args;
    const options = mergeObjects({
      populateCache: true,
      throwOnError: true
    }, typeof _opts === "boolean" ? {
      revalidate: _opts
    } : _opts || {});
    let populateCache = options.populateCache;
    const rollbackOnErrorOption = options.rollbackOnError;
    let optimisticData = options.optimisticData;
    const revalidate = options.revalidate !== false;
    const rollbackOnError = (error) => {
      return typeof rollbackOnErrorOption === "function" ? rollbackOnErrorOption(error) : rollbackOnErrorOption !== false;
    };
    const throwOnError = options.throwOnError;
    if (isFunction(_key)) {
      const keyFilter = _key;
      const matchedKeys = [];
      const it = cache2.keys();
      for (let keyIt = it.next(); !keyIt.done; keyIt = it.next()) {
        const key = keyIt.value;
        if (
          // Skip the special useSWRInfinite keys.
          !key.startsWith("$inf$") && keyFilter(cache2.get(key)._k)
        ) {
          matchedKeys.push(key);
        }
      }
      return Promise.all(matchedKeys.map(mutateByKey));
    }
    return mutateByKey(_key);
    async function mutateByKey(_k) {
      const [key] = serialize(_k);
      if (!key)
        return;
      const [get, set] = createCacheHelper(cache2, key);
      const [EVENT_REVALIDATORS, MUTATION, FETCH] = SWRGlobalState.get(cache2);
      const revalidators = EVENT_REVALIDATORS[key];
      const startRevalidate = () => {
        if (revalidate) {
          delete FETCH[key];
          if (revalidators && revalidators[0]) {
            return revalidators[0](MUTATE_EVENT).then(() => get().data);
          }
        }
        return get().data;
      };
      if (args.length < 3) {
        return startRevalidate();
      }
      let data = _data;
      let error;
      const beforeMutationTs = getTimestamp();
      MUTATION[key] = [
        beforeMutationTs,
        0
      ];
      const hasOptimisticData = !isUndefined(optimisticData);
      const state = get();
      const displayedData = state.data;
      const currentData = state._c;
      const committedData = isUndefined(currentData) ? displayedData : currentData;
      if (hasOptimisticData) {
        optimisticData = isFunction(optimisticData) ? optimisticData(committedData) : optimisticData;
        set({
          data: optimisticData,
          _c: committedData
        });
      }
      if (isFunction(data)) {
        try {
          data = data(committedData);
        } catch (err) {
          error = err;
        }
      }
      if (data && isFunction(data.then)) {
        data = await data.catch((err) => {
          error = err;
        });
        if (beforeMutationTs !== MUTATION[key][0]) {
          if (error)
            throw error;
          return data;
        } else if (error && hasOptimisticData && rollbackOnError(error)) {
          populateCache = true;
          data = committedData;
          set({
            data,
            _c: UNDEFINED
          });
        }
      }
      if (populateCache) {
        if (!error) {
          if (isFunction(populateCache)) {
            data = populateCache(data, committedData);
          }
          set({
            data,
            _c: UNDEFINED
          });
        }
      }
      MUTATION[key][1] = getTimestamp();
      const res = await startRevalidate();
      set({
        _c: UNDEFINED
      });
      if (error) {
        if (throwOnError)
          throw error;
        return;
      }
      return populateCache ? res : data;
    }
  }
  var revalidateAllKeys = (revalidators, type) => {
    for (const key in revalidators) {
      if (revalidators[key][0])
        revalidators[key][0](type);
    }
  };
  var initCache = (provider, options) => {
    if (!SWRGlobalState.has(provider)) {
      const opts = mergeObjects(defaultConfigOptions, options);
      const EVENT_REVALIDATORS = {};
      const mutate2 = internalMutate.bind(UNDEFINED, provider);
      let unmount = noop;
      const subscriptions = {};
      const subscribe = (key, callback) => {
        const subs = subscriptions[key] || [];
        subscriptions[key] = subs;
        subs.push(callback);
        return () => subs.splice(subs.indexOf(callback), 1);
      };
      const setter = (key, value, prev) => {
        provider.set(key, value);
        const subs = subscriptions[key];
        if (subs) {
          for (let i3 = subs.length; i3--; ) {
            subs[i3](prev, value);
          }
        }
      };
      const initProvider = () => {
        if (!SWRGlobalState.has(provider)) {
          SWRGlobalState.set(provider, [
            EVENT_REVALIDATORS,
            {},
            {},
            {},
            mutate2,
            setter,
            subscribe
          ]);
          if (!IS_SERVER) {
            const releaseFocus = opts.initFocus(setTimeout.bind(UNDEFINED, revalidateAllKeys.bind(UNDEFINED, EVENT_REVALIDATORS, FOCUS_EVENT)));
            const releaseReconnect = opts.initReconnect(setTimeout.bind(UNDEFINED, revalidateAllKeys.bind(UNDEFINED, EVENT_REVALIDATORS, RECONNECT_EVENT)));
            unmount = () => {
              releaseFocus && releaseFocus();
              releaseReconnect && releaseReconnect();
              SWRGlobalState.delete(provider);
            };
          }
        }
      };
      initProvider();
      return [
        provider,
        mutate2,
        initProvider,
        unmount
      ];
    }
    return [
      provider,
      SWRGlobalState.get(provider)[4]
    ];
  };
  var onErrorRetry = (_4, __, config, revalidate, opts) => {
    const maxRetryCount = config.errorRetryCount;
    const currentRetryCount = opts.retryCount;
    const timeout = ~~((Math.random() + 0.5) * (1 << (currentRetryCount < 8 ? currentRetryCount : 8))) * config.errorRetryInterval;
    if (!isUndefined(maxRetryCount) && currentRetryCount > maxRetryCount) {
      return;
    }
    setTimeout(revalidate, timeout, opts);
  };
  var compare = (currentData, newData) => stableHash(currentData) == stableHash(newData);
  var [cache, mutate] = initCache(/* @__PURE__ */ new Map());
  var defaultConfig = mergeObjects(
    {
      // events
      onLoadingSlow: noop,
      onSuccess: noop,
      onError: noop,
      onErrorRetry,
      onDiscarded: noop,
      // switches
      revalidateOnFocus: true,
      revalidateOnReconnect: true,
      revalidateIfStale: true,
      shouldRetryOnError: true,
      // timeouts
      errorRetryInterval: slowConnection ? 1e4 : 5e3,
      focusThrottleInterval: 5 * 1e3,
      dedupingInterval: 2 * 1e3,
      loadingTimeout: slowConnection ? 5e3 : 3e3,
      // providers
      compare,
      isPaused: () => false,
      cache,
      mutate,
      fallback: {}
    },
    // use web preset by default
    preset
  );
  var mergeConfigs = (a3, b3) => {
    const v3 = mergeObjects(a3, b3);
    if (b3) {
      const { use: u1, fallback: f1 } = a3;
      const { use: u22, fallback: f22 } = b3;
      if (u1 && u22) {
        v3.use = u1.concat(u22);
      }
      if (f1 && f22) {
        v3.fallback = mergeObjects(f1, f22);
      }
    }
    return v3;
  };
  var SWRConfigContext = B({});
  var SWRConfig = (props) => {
    const { value } = props;
    const parentConfig = q2(SWRConfigContext);
    const isFunctionalConfig = isFunction(value);
    const config = F(() => isFunctionalConfig ? value(parentConfig) : value, [
      isFunctionalConfig,
      parentConfig,
      value
    ]);
    const extendedConfig = F(() => isFunctionalConfig ? config : mergeConfigs(parentConfig, config), [
      isFunctionalConfig,
      parentConfig,
      config
    ]);
    const provider = config && config.provider;
    const [cacheContext] = p2(() => provider ? initCache(provider(extendedConfig.cache || cache), config) : UNDEFINED);
    if (cacheContext) {
      extendedConfig.cache = cacheContext[0];
      extendedConfig.mutate = cacheContext[1];
    }
    useIsomorphicLayoutEffect(() => {
      if (cacheContext) {
        cacheContext[2] && cacheContext[2]();
        return cacheContext[3];
      }
    }, []);
    return h(SWRConfigContext.Provider, mergeObjects(props, {
      value: extendedConfig
    }));
  };
  var enableDevtools = isWindowDefined && window.__SWR_DEVTOOLS_USE__;
  var use = enableDevtools ? window.__SWR_DEVTOOLS_USE__ : [];
  var setupDevTools = () => {
    if (enableDevtools) {
      window.__SWR_DEVTOOLS_REACT__ = bn;
    }
  };
  var normalize = (args) => {
    return isFunction(args[1]) ? [
      args[0],
      args[1],
      args[2] || {}
    ] : [
      args[0],
      null,
      (args[1] === null ? args[2] : args[1]) || {}
    ];
  };
  var useSWRConfig = () => {
    return mergeObjects(defaultConfig, q2(SWRConfigContext));
  };
  var middleware = (useSWRNext) => (key_, fetcher_, config) => {
    const fetcher = fetcher_ && ((...args) => {
      const key = serialize(key_)[0];
      const [, , , PRELOAD] = SWRGlobalState.get(cache);
      const req = PRELOAD[key];
      if (req) {
        delete PRELOAD[key];
        return req;
      }
      return fetcher_(...args);
    });
    return useSWRNext(key_, fetcher, config);
  };
  var BUILT_IN_MIDDLEWARE = use.concat(middleware);
  var withArgs = (hook) => {
    return function useSWRArgs(...args) {
      const fallbackConfig = useSWRConfig();
      const [key, fn2, _config] = normalize(args);
      const config = mergeConfigs(fallbackConfig, _config);
      let next = hook;
      const { use: use2 } = config;
      const middleware2 = (use2 || []).concat(BUILT_IN_MIDDLEWARE);
      for (let i3 = middleware2.length; i3--; ) {
        next = middleware2[i3](next);
      }
      return next(key, fn2 || config.fetcher || null, config);
    };
  };
  var subscribeCallback = (key, callbacks, callback) => {
    const keyedRevalidators = callbacks[key] || (callbacks[key] = []);
    keyedRevalidators.push(callback);
    return () => {
      const index = keyedRevalidators.indexOf(callback);
      if (index >= 0) {
        keyedRevalidators[index] = keyedRevalidators[keyedRevalidators.length - 1];
        keyedRevalidators.pop();
      }
    };
  };
  setupDevTools();

  // node_modules/swr/core/dist/index.mjs
  var WITH_DEDUPE = {
    dedupe: true
  };
  var useSWRHandler = (_key, fetcher, config) => {
    const { cache: cache2, compare: compare2, suspense, fallbackData, revalidateOnMount, refreshInterval, refreshWhenHidden, refreshWhenOffline, keepPreviousData } = config;
    const [EVENT_REVALIDATORS, MUTATION, FETCH] = SWRGlobalState.get(cache2);
    const [key, fnArg] = serialize(_key);
    const initialMountedRef = _2(false);
    const unmountedRef = _2(false);
    const keyRef = _2(key);
    const fetcherRef = _2(fetcher);
    const configRef = _2(config);
    const getConfig = () => configRef.current;
    const isActive = () => getConfig().isVisible() && getConfig().isOnline();
    const [getCache, setCache, subscribeCache] = createCacheHelper(cache2, key);
    const stateDependencies = _2({}).current;
    const fallback = isUndefined(fallbackData) ? config.fallback[key] : fallbackData;
    const isEqual = (prev, current) => {
      let equal = true;
      for (const _4 in stateDependencies) {
        const t3 = _4;
        if (!compare2(current[t3], prev[t3])) {
          if (t3 === "data" && isUndefined(prev[t3])) {
            if (!compare2(current[t3], returnedData)) {
              equal = false;
            }
          } else {
            equal = false;
          }
        }
      }
      return equal;
    };
    const getSnapshot = F(() => {
      const shouldStartRequest = (() => {
        if (!key)
          return false;
        if (!fetcher)
          return false;
        if (!isUndefined(revalidateOnMount))
          return revalidateOnMount;
        if (getConfig().isPaused())
          return false;
        if (suspense)
          return false;
        return true;
      })();
      const getSelectedCache = () => {
        const state = getCache();
        const snapshot = mergeObjects(state);
        delete snapshot._k;
        if (!shouldStartRequest) {
          return snapshot;
        }
        return {
          isValidating: true,
          isLoading: true,
          ...snapshot
        };
      };
      let memorizedSnapshot = getSelectedCache();
      return () => {
        const snapshot = getSelectedCache();
        return isEqual(snapshot, memorizedSnapshot) ? memorizedSnapshot : memorizedSnapshot = snapshot;
      };
    }, [
      cache2,
      key
    ]);
    const cached = (0, import_shim.useSyncExternalStore)(T2(
      (callback) => subscribeCache(key, (prev, current) => {
        if (!isEqual(prev, current))
          callback();
      }),
      // eslint-disable-next-line react-hooks/exhaustive-deps
      [
        cache2,
        key
      ]
    ), getSnapshot, getSnapshot);
    const isInitialMount = !initialMountedRef.current;
    const cachedData = cached.data;
    const data = isUndefined(cachedData) ? fallback : cachedData;
    const error = cached.error;
    const laggyDataRef = _2(data);
    const returnedData = keepPreviousData ? isUndefined(cachedData) ? laggyDataRef.current : cachedData : data;
    const shouldDoInitialRevalidation = (() => {
      if (isInitialMount && !isUndefined(revalidateOnMount))
        return revalidateOnMount;
      if (getConfig().isPaused())
        return false;
      if (suspense)
        return isUndefined(data) ? false : config.revalidateIfStale;
      return isUndefined(data) || config.revalidateIfStale;
    })();
    const defaultValidatingState = !!(key && fetcher && isInitialMount && shouldDoInitialRevalidation);
    const isValidating = isUndefined(cached.isValidating) ? defaultValidatingState : cached.isValidating;
    const isLoading = isUndefined(cached.isLoading) ? defaultValidatingState : cached.isLoading;
    const revalidate = T2(
      async (revalidateOpts) => {
        const currentFetcher = fetcherRef.current;
        if (!key || !currentFetcher || unmountedRef.current || getConfig().isPaused()) {
          return false;
        }
        let newData;
        let startAt;
        let loading = true;
        const opts = revalidateOpts || {};
        const shouldStartNewRequest = !FETCH[key] || !opts.dedupe;
        const callbackSafeguard = () => {
          if (IS_REACT_LEGACY) {
            return !unmountedRef.current && key === keyRef.current && initialMountedRef.current;
          }
          return key === keyRef.current;
        };
        const finalState = {
          isValidating: false,
          isLoading: false
        };
        const finishRequestAndUpdateState = () => {
          setCache(finalState);
        };
        const cleanupState = () => {
          const requestInfo = FETCH[key];
          if (requestInfo && requestInfo[1] === startAt) {
            delete FETCH[key];
          }
        };
        const initialState = {
          isValidating: true
        };
        if (isUndefined(getCache().data)) {
          initialState.isLoading = true;
        }
        try {
          if (shouldStartNewRequest) {
            setCache(initialState);
            if (config.loadingTimeout && isUndefined(getCache().data)) {
              setTimeout(() => {
                if (loading && callbackSafeguard()) {
                  getConfig().onLoadingSlow(key, config);
                }
              }, config.loadingTimeout);
            }
            FETCH[key] = [
              currentFetcher(fnArg),
              getTimestamp()
            ];
          }
          [newData, startAt] = FETCH[key];
          newData = await newData;
          if (shouldStartNewRequest) {
            setTimeout(cleanupState, config.dedupingInterval);
          }
          if (!FETCH[key] || FETCH[key][1] !== startAt) {
            if (shouldStartNewRequest) {
              if (callbackSafeguard()) {
                getConfig().onDiscarded(key);
              }
            }
            return false;
          }
          finalState.error = UNDEFINED;
          const mutationInfo = MUTATION[key];
          if (!isUndefined(mutationInfo) && // case 1
          (startAt <= mutationInfo[0] || // case 2
          startAt <= mutationInfo[1] || // case 3
          mutationInfo[1] === 0)) {
            finishRequestAndUpdateState();
            if (shouldStartNewRequest) {
              if (callbackSafeguard()) {
                getConfig().onDiscarded(key);
              }
            }
            return false;
          }
          const cacheData = getCache().data;
          finalState.data = compare2(cacheData, newData) ? cacheData : newData;
          if (shouldStartNewRequest) {
            if (callbackSafeguard()) {
              getConfig().onSuccess(newData, key, config);
            }
          }
        } catch (err) {
          cleanupState();
          const currentConfig = getConfig();
          const { shouldRetryOnError } = currentConfig;
          if (!currentConfig.isPaused()) {
            finalState.error = err;
            if (shouldStartNewRequest && callbackSafeguard()) {
              currentConfig.onError(err, key, currentConfig);
              if (shouldRetryOnError === true || isFunction(shouldRetryOnError) && shouldRetryOnError(err)) {
                if (isActive()) {
                  currentConfig.onErrorRetry(err, key, currentConfig, revalidate, {
                    retryCount: (opts.retryCount || 0) + 1,
                    dedupe: true
                  });
                }
              }
            }
          }
        }
        loading = false;
        finishRequestAndUpdateState();
        return true;
      },
      // `setState` is immutable, and `eventsCallback`, `fnArg`, and
      // `keyValidating` are depending on `key`, so we can exclude them from
      // the deps array.
      //
      // FIXME:
      // `fn` and `config` might be changed during the lifecycle,
      // but they might be changed every render like this.
      // `useSWR('key', () => fetch('/api/'), { suspense: true })`
      // So we omit the values from the deps array
      // even though it might cause unexpected behaviors.
      // eslint-disable-next-line react-hooks/exhaustive-deps
      [
        key,
        cache2
      ]
    );
    const boundMutate = T2(
      // Use callback to make sure `keyRef.current` returns latest result every time
      (...args) => {
        return internalMutate(cache2, keyRef.current, ...args);
      },
      // eslint-disable-next-line react-hooks/exhaustive-deps
      []
    );
    useIsomorphicLayoutEffect(() => {
      fetcherRef.current = fetcher;
      configRef.current = config;
      if (!isUndefined(cachedData)) {
        laggyDataRef.current = cachedData;
      }
    });
    useIsomorphicLayoutEffect(() => {
      if (!key)
        return;
      const softRevalidate = revalidate.bind(UNDEFINED, WITH_DEDUPE);
      let nextFocusRevalidatedAt = 0;
      const onRevalidate = (type) => {
        if (type == constants.FOCUS_EVENT) {
          const now = Date.now();
          if (getConfig().revalidateOnFocus && now > nextFocusRevalidatedAt && isActive()) {
            nextFocusRevalidatedAt = now + getConfig().focusThrottleInterval;
            softRevalidate();
          }
        } else if (type == constants.RECONNECT_EVENT) {
          if (getConfig().revalidateOnReconnect && isActive()) {
            softRevalidate();
          }
        } else if (type == constants.MUTATE_EVENT) {
          return revalidate();
        }
        return;
      };
      const unsubEvents = subscribeCallback(key, EVENT_REVALIDATORS, onRevalidate);
      unmountedRef.current = false;
      keyRef.current = key;
      initialMountedRef.current = true;
      setCache({
        _k: fnArg
      });
      if (shouldDoInitialRevalidation) {
        if (isUndefined(data) || IS_SERVER) {
          softRevalidate();
        } else {
          rAF(softRevalidate);
        }
      }
      return () => {
        unmountedRef.current = true;
        unsubEvents();
      };
    }, [
      key
    ]);
    useIsomorphicLayoutEffect(() => {
      let timer;
      function next() {
        const interval = isFunction(refreshInterval) ? refreshInterval(data) : refreshInterval;
        if (interval && timer !== -1) {
          timer = setTimeout(execute, interval);
        }
      }
      function execute() {
        if (!getCache().error && (refreshWhenHidden || getConfig().isVisible()) && (refreshWhenOffline || getConfig().isOnline())) {
          revalidate(WITH_DEDUPE).then(next);
        } else {
          next();
        }
      }
      next();
      return () => {
        if (timer) {
          clearTimeout(timer);
          timer = -1;
        }
      };
    }, [
      refreshInterval,
      refreshWhenHidden,
      refreshWhenOffline,
      key
    ]);
    x2(returnedData);
    if (suspense && isUndefined(data) && key) {
      if (!IS_REACT_LEGACY && IS_SERVER) {
        throw new Error("Fallback data is required when using suspense in SSR.");
      }
      fetcherRef.current = fetcher;
      configRef.current = config;
      unmountedRef.current = false;
      throw isUndefined(error) ? revalidate(WITH_DEDUPE) : error;
    }
    return {
      mutate: boundMutate,
      get data() {
        stateDependencies.data = true;
        return returnedData;
      },
      get error() {
        stateDependencies.error = true;
        return error;
      },
      get isValidating() {
        stateDependencies.isValidating = true;
        return isValidating;
      },
      get isLoading() {
        stateDependencies.isLoading = true;
        return isLoading;
      }
    };
  };
  var SWRConfig2 = OBJECT.defineProperty(SWRConfig, "defaultValue", {
    value: defaultConfig
  });
  var useSWR = withArgs(useSWRHandler);

  // src/popup/App.tsx
  var import_webextension_polyfill = __toESM(require_browser_polyfill());

  // src/logo.png
  var logo_default = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAABJsklEQVR42u29d5Td13Ue+p3yK7dOr5jBYDDovbIAYqdYJNKyZKrYXpLtOM/PUexnJ3HeSrxe1npv5TnrrThxEsclcmzLUixTliiJFqtYwIpCorcBMDPA9Jk75d65/f7KOWe/P34DEKJISRRBAqDxrYW1ABAg7j3nO/vs/e1ygBu4gRu4gRu4gRv4xwh28SfFiYmmMBYLqVpNhV6xjpPltTY1zbOmpuJHfRGmiOKdjFX/URKAiPjs0FDvqZdefCRZ81O50bFlpXyxDpKrjp5l55tuvXlPvLFxOrFkyVBLS0vpo7YA3zlz5LfPF7NbltU3vrFC1h/Z1td36B8TAeSpPc9+6tyBN+6Zf+PI7qZSqTmczrTADx3uWKHfMVQ8dezI7mR354UlN938Unl4+Mlkb2/mo7QAJ01p96On934+Tfyzq2L1F776xp5vbOpc9oN0fWx6Zapj7iNPgPzjL31p6tU9t6f9alqXCzLFCaQDaCOs/IVsU9tEU9N8/8DmgeHxFX65Wj8/Pv5oc3f35EdlAYTHijkdYCFppyaC6c2DA4VlfZMnf3lFR+eZNzJn/2d3PH2iI9VRYoz5H0kCmDOHbuus5BvtSg01h2BBwPcZ6rSFKghllUeshJg+VrlpVgeJir9QPzc38qfNzT2zjDF93d+BTPO5BOBygBwbWcvUTZdmNh8L5jf3V+d2uk7M+0Sy769mZ2cfbW1tzXzkCDA3OtLkV6pwSMIVDnTJgy0saBNAOwAzFjhnMLUa/DNDawue51plnZjasPrN2fP9h1r71g1ezwtAXHDLMMSIwRgGDwZVIZA1PmZnh/vsUGAhUfztnOe1jObzf9hTX7/wkSKAIyWYbcOBg5LRABk4jIHIQKsAlrHBBIMUDFa1xsNzF/rKwQ++ON9/bGdmde+p8yfO/GnfprUnr18TaChW07CFhnRj0FDwEaDmOFCCgwngQG2htzw+8GuKpDOSyfzJsvb24Y8MAfymllKpMp2yjUItrCLlMATMIEECLtlwIOAZjQAKFuOwvQB8dKwpmBrf7Q8Obj5jNZfmzp79y5Y1a85djwuwqrFj//2rtt5V9GvxsVy2reJ5sCwHjICgGkAJC1UChozf/ncTp/9pwVTrL8zM/L6rdamzs/O6Dx1lbcfOl6o4sqM8Nt1pcQ7BCAEjhFqAMReh0oAgMGIIoWCIgXkBEh5g+fnk7PPPfKY/rNkTp079ddeGDcevtwW4tWfV3zW0NQ0vKL/55NjIfUdGBm+7kM2snCrVQJJDQsAIhjkEyAfVtM4MfBYW410eHxienf1q73XuF8h1v/bF/zbR2v5I4YmnfzHuF+ors1NglkRFE+AwKBUizm3YjIORBHGCAQe0BgKF9ODA8smq9wUl3XDk5EAge9pnu9Lp7PWyAIsC0IsAQETfebG9996n+4/87vNj/feN6zKTYYhq3EUYeBDCwgWvkPrG1KlfXRLKzExMLBleWPi/ehsa8tctAbZv3r7n7KFD1F8pp00+0147cPhmt1JNWl4JBA1HWGAGCLUGgwHngKYARATFGOIeUBsfb1148cWfn1CBy7u6hubOnHm6Ze3agesvImAKwLOH/dxUPBmbe+b4wYdD5VvTNT8OW8IRAjVlMFhdwByz2muTZ760hJzhY9Ojz27p6Dl9XRIAAFZv3/5aSCEtZKdXhj6kOXZsa6zspU1YgaOTCDkQcA0IDpsTEGoIAZDg8EjANgY4P9JXBv98Jm7PVAsLjaVM5k9S7e2z1+OibHcaTxz2S/+hO1Z/djrML3vmyKFPjoeqYyH0AFsgJWxQqHG+mk89evbAr+cddBzzin9R56TGlgFmqFyuqxSzXToIHQkiYchowTVTihmSxonxSn1dfIGS7ZWrLUHLy5j/8uzs7CHXThX8xvbPzjz59Kd4mSyhAIKCZAG4tKB8wBYpkAmhwwDQAq4tQH4N5tyZ5tZEsrkWGucUs4L58fGvXq+i0XYndeY00R8aVBpa3bqhv9n3/JdDrpaWpIUKogPgMI7TOlhbGj7dOezXtrQwdxRKmXyl2FIK/eZctVQPW0jXcZUKAgZDxubCS0gn31RfP+XaZypfO/HGUIxZhQ43dr69sXVoZVPTxIdOgItobW0tF6em9pR8JUw20zu7b/92MkUQaTBi0AFDqAAwggoVYjaH0RpBoGBAsKUFqhiULpzvCl7f+yAAZEbOfqN92ZrrMmxaz1gAYOYQVb6eZ2Hjo4de/3KtUkiSI8EhwMEx4SosVOfrhs7M3uMqwLVsBEzDIw0mBXyfIGsSOgwhuYDFBUhpuHkLknMkIIIU47WuWP1EV7L+zH964/nhZuFO9DW0HlmzvPF4C/tg8y/y7b+R7uycLxTGf1A/O7VqbPBCly2CNlR9oEZgxOE4DpjFobQPzhm4FFAwYKQhuAFXPuyc54YnTmzJlctNAWOUHRr6OmtsLDY2NhauS2uA+Eyxb+PfHZ0Y/2RuanB9LgjALA4NBuG6MBIosRAFHsAwD5ZrQTGOwPcA6YILgiEGKTkkY1BE4AjAwSG0tqUx9mBQrkuVZ9Y72oSuMpVldY3jK+a7Tj5z7uRjN7cs2fNBrZ18p9+sq+vOTZ058WTD0PiKhcOv35us+AmamEk5vgdjagg9AyINwx1QoMGlhZABgQ5hE5AAoPILcdPfv3pOsl84HpTS8Y6lZ7PZ7HearsP08gmUm6cWchun5mYawAUsOw5PBWDcAhU8GC5gcQbLjoFZDNVqFZJxNIg4QkVgGjCGgUIFAQZJBAgOwTiYAYgJFLlBjjxwCQtQ9cO1mfo3JvIb+6fHtg+V1z32xtj5xxscmVvV1nPhijq+P+4/njv8xm3zx8/crofH1ky+8Nz99tRoi6OqICIYbiPQDDHiMFJAgUBawYaBBIGIQRODSNdDr+0d8GNNM0seuOfbPfff/1fXuoBCROxokFs7U6kuqyiTfK3/2BdOZzMbB7z5FQvcoAIFLixwHm2iLSXCcg2+V0VDug5+tQKXOCxiCFUAIQQ4AcYYSCnBLQlfK2itASeOAAbKAqqhDzcWgwpD2IIDREgog+VWXXF9ovlkj5MYuKtv01/d3rNi7wdqAS6pZNtu2p/quOlw7fyBXbm5mZaqKn0Mc34iTgYQEqFH4EJA6YjFwpIAaRgTAkQQXCKWzyE47q8SMrlqOvQdnnarU1NT/9DZ2Tl/LW7+6XK5/bHJgfv2jpz93PHJ4fUFo+t80ukprygq3EAmY7BggZSGJAKnEKZaRR2zYIsYTLaELjdZ2rFu3fnGRDqTSsbnAGKkSAZhECcGEWidmJmf7c0VC/Hx7EJ9SSurHGoIBrhGwIOB0gTFgJrkOOktpEfC8u4WODfNQnW+ODb4R3d3r3iVMeZ9oARYjA5UJpPZv/ZTD/7NsDRm9qUXPq4WFqQdBnCcBLRXBWkGzh1wHbHWEMAYANKoCQEUy0hYBuHAwKbJbz72v2N2vn1u7OxXW5aumboWNn2QyAHgZMLCyu+cOfyl1wZOPThSza8oIGTK5vBUAJ5yEHds+J4H1ALU2Q5scDglH1Zg8quaW0fvvuWm7yS5lauX8eyytpZTrs1rgB1wMOZAeQG4SCDuhYCVKc2trvpeQ0EF9WPZ+a2HRs8+cGF+rmtmtpB0XBtlAUhHggGoCSB0JCqBb9UyQ/eXTdiUqxW+AuAvP1ACXER7e3uFMpknapNzPZXzY2sdNrrMm50BoQabGzjCAYjDKAVtFGwrSqIEYQg/FoPjOqh4PlCYd+Wb1Z2zBb+epeLewvCZ75h0a+5q+gWHiKzjA8e+cHJ26u7RsLzmzNx030gp2+Q5EsqJlkcjyohWiiXEhYRru7AVAUENGxs7Dn/ytrv/pNuOjy+vazjegJTXyliZiOTiAXo3zALAMJF7W3vfd9Z19zw/UcxtOjly4RN5o7pPTY71zJQKrJK0wbmM1ldKTFcr2D8/usMKQvXyxND5O7tWvPSB+QBvx8zgYN/ovtc/e/Kx7/yThqmZPidf4FbJx5zlI+VwOKUAVRCsWBKsGsCOWahyBlVTcDTgCIZAKtRSLuzlfTP1K9ced7o7B7ofuOdrnRtvviqlWF8/uf83/9PJF/7Q00iWQBAhUIlxBDZHRfkAAxwSSBsg5iskNWa3L19xOq3t3NqeZa/vbl3+VFe6JdPCWOn9+h3TQGzB85orJmg7Ozt+15HB/k8+M3b29llHQyVj0EEIxhi0DrEktPBw78bnH2jr+0pLLD64vXv5iQ/MAlzSCVasGNHF4vPFifFe79z5YnF4ZIkzOdYutQRqBNepAwB4JgSLC+R0CXHjwBICzJbQnKCMQVipwB8ebvNz5Y/xk/Gbqn4Ymzy4/6tLdt6698MmwJzx2sdVNekRA4+5sCVHkSmYgFCfSIJpBhTLSAeg1Q3tJz59y+1/tKql82jasFLapYXlaKgyxsIrIEMTgCqAMQBjo0RDfU0dr9mJ5O8/03/oE+PFHHdTcYSuROBIFASwLzN8T7la6VydbHhleHr6D3s7OkY+UAIwxjQRHQ3D8H/llw+fzgwNbQheee4RjEw3mGoNVUbQRFCkIBIcAgzkB4CwUOMExhgY44iTAcpVsPJUXBoWn1fBIyxUsak394rOm3a/+mESIE+qaUEY8FQKtrBRzVZhJSzEQiA+X4ZNEkviTaOrW5qOP3LLnX+4uaHjyIch3/YwtgBg/4FC5g8couDVC2fvK0qTHK+VoWJAjgjclPlYobp+qJJd0pVuPAngf3ygBFgkgSGig86y5oHkmjU9k8X5tnx2/wMsmLdLxoOlDQRnQBCgnrvQDiEAAQBCQ7CMgMU4JBkwEyBmJEoj43WzL7z+kG2EHDuw1+1evnIfa20tfygJIGkzJiyYIETg+WiBDVlj6LUSE9uWLn1RCqHu2rrt0S4ncb7erc90XgHP+72gKd129Od33vr/LOnqvJDxqju/f3T/HcbUUIGCLzhKNofyi/V7ZkZ++fT09KvrOzr6P1ACLJLABzBLRHlv+I7Ha5MLnd6ZE9uQr/CYAJgCvIBAjCGUBEUEEGBzEeXXtYYPAkEhgIY0LjA1k86+sv8hFfhNhY3rXxzft29f965dr3zgBCBi0lOoT8TBdIBOLbO9ze1DP79l13+9tXvV9wKA1gGKMWauho+ykjH/W0Rn7+xx/su0ClYNDZ//y8LMSB+LWSirEELGUOIK+0tTH1s73f9Pcrncv38vqqF8n/dWMDU19YSXz7eM1nKNXv/C8pQ28D0PXDioaQalDIgIghvYJMFJQINBc8DYDKE24IzD8j2osfF4Afru0vDoxvnVK24d3/darHvXbc9+oCtc8ZJ9VgpOGbW4SOQf2rH7z7ctW/bSmlTHod5rpBL4c4wFRJSBBG5ZtvrpoZnpf7ZQLUuTsCArAXhMYkJX8MrM8C9tS3e9COCZD4UAANDZ2Tk/PXzmW7VqsS40/HNhsdQSZGbrrGoNjIWIcRsGIYg0QCEMEYgEGABGHIIIgfIBUiDfB88axorZ1vL87APDxren9r5Z7di1c99PCKl+ZqxJNR/+dN/G5Mr6zhea29vPddctObKVsfyP89YBiA/q8/y4qxfA1GEq/fnAzNTt0xeOb64ZAwZAhApKGIxVFzpGirPbP1QCAEBH79qRqfPnvxL6EGpycjUbGNganD7d42gFChhgKRAPYRBtvGACAhykNaQCNAyEayEwAYJyFkJJqFzemhd697xxf2dzUEkDePKDWNhNjUteXLO87/tbYw0/0YM+TeX2b50++HDvyr59x6vVQn0sVll01j40JMALW5ctf+5kdmpzsTyDwLVhah6YBXi2QinwuonIZlEm88MhAAB09vWN9Z8//1fxkpecfPzJfzaXzT9iZi80UMAQCwkFQUAokCIXyhYIgjIsm6CJI8YEyNfgDAiJEDANIIAcOp9MVNhnRqr5tsGXn4ux1q4zK9atO3UlPu/s7Gwyl5vdCWOmftLmExHfWy1s+0F//8MnBvofqpsZ/xUpTHXVyhUvHPRzTzfbDUO9H5JzuBrxmXyq/fk1bd2fP1nILE0aoCpFlIJmHKeK2Y+dL84tBTD0oRIAANYuX34eAKP52e+GC5NLMq/m7hPzC9JmHIwxWA6HDhQUAzjngDEwABg4CAaEKHQ0ABgBzBCqc2PwD3s7QebfipaOcxeee+67y++779vv53MuLCzUz8/MfDw3n9vQlqh77N3+3FGvsLJswsavzw5u2TfQ/6unZyY2jM1OJ928A1IhGjPDu7Jbdm1eXt/yygnPeyHlODkf0Gvepyj0k0Lx05433JKqm0wya2nJj1LTioD5ShlTyLVkvFrvVSHARU+ZiPb4QbEpt1BIh8eP3uxn8xZBAzAItEIoDVzJIIxAKGgxSLz0/4AAAENgZKC9BWC8bCsv3OolGzZOzs0tm3t1T7Xl9rufeq+fL5vNdlerpY2ZzNSW7Pz8Ds/zSoHv2z9i6mu5pSfGRu//6us/+NwcBT0Zr9J+Zn4qVbMFVH0MFgOgLSwYL/H1o3t/aWmi4d5N7d2f70o1HG2Op0bf9LN7dtqN/YvizhVH3HEmlja07u1007eer+UBLiAkg0KIrKo1ThQXtg9ls2dXNDWNf6gEuDw6WBgefip3f61hwfj1lcOnN0hTA4ol2NDQjEMbDoDDLG4/Jw4wgF+kAxmQIRipIRUHFhbAi2WZqRW3K4f/Tv/TTzStfXDN3zO28id66kTEstnszomJ0d8vFUs7iLStfDXPtDkpSV4kLQdA+0qztzzef+RX9o8OPnCmONdjNKHKCAWmAWGBCwteqCCFBWIc434Fc7Vq62h+/u46I27qStfPfGzF2lWmZ9U3iOjgB9E+18uY99TCzIme+pbSeKWQ0oECgUCWQFEbMTw/c0er4mPDC8NP9zb05j90AgBAQ29vfnx8/HtONdt+YaHWEPMqqWDoQtqGB8UMQjLQQHTaARgG8IgKYAQQNJghSOPCgKNSq4IzAVarWvnX9t9ZK1XqLc9PEdFXfpxHTkRscnLyN+bnZn4rn89tCH0Ptm0DIKZCPxk6PLWvNnfHk/MXusqVWv2BiQuP7B0+d+uILjrluISrBUIYSCeBUBMMKTDGYAyBmAElYlCGYU4pzFTKyelcJZkdCL80ms9tPd3V+/TxXOb7LQ1tF660elhvOTMtiXQpLkTKNxqkDSCi6qxq4Ld4YdiopGtdFQtwEd3d3ZPZ08ceLc2WW6x8rjVT9W+rTY43aeOBMQZwARgNgIPTJWXmrc3jDFJbYFKgonwYppA0EmJqzqr5R3bOhGGjcmw18MqeuZW3dz/1TtYgn8/flpme/JelUmEVQYExgg4DMMbqpSV7+zMT/3rvdHbr8NxMvFz1MKrKDVmqoewwBILgMQJIw4IA1wFEAFjCBjEOBYIKFJhlQTkWlHARgFCozqbPn5/bfWB+bPfpVPsDXc2tZ56YOv/Kmo6OV1cgNnklrgZLCI9zro0xsG0JRzAYYlGRimWRI6Vn65i6qgQAgKb1W06P7z/017XyfFdFKVN+1XtQZTOxmCYQRQ7g5ctBxEBYFN04IdQhXOJwmICGAUGDamWYjI/cYdVX8f3/2zQ1z8b8T8QB/O1l933a1bpvZGriDyqV0iqlfQgQwBQia89kzHGXPzd2ofNJNVGXDzwoMijbHJYjYXEOaTSIW2AKsEs1NIkYEkyUHWaFHmOJfLVqm5iDmufDEwTFo14J7UhkA42ql8d8NnubM3zmtqX1jZ++fd2Wl29ZtuqvLlD52HKWnHk/mcN9XkF6OrRKgQfYLogzaK1hGIFxppUOLe3n7KtOAADovnXHG0TDx4NSoXFkdGiz9gt9vOQhrPiQtgUGXOYIsh9yCAPHQIQ+LBa1aPnQEDAA4/CKeaROnW2fcaz2U1L89rnnn+etO3Z835fSnhwb/E0K9X0L+dJuozWICKH24doOpJQIvRBh6Dt5ZpwRVYJ2BDiTUDYD9wlOoCG1hjA+klygEcn5XcvXvNzb1HHUlo6X86odg2MTdx6bH91aDJmICQtVGFRUAC4lLMdGoDRm4wSLCNnSTMvMsdc/O5CZ3Hxz3+pn9oXFb6WkPdMEZ7oD8N6j1My01lagQhjJARGt2cUSNc55RVrSi1O8fE0QINrMXi+TyfxDdqbYWlLic7Vz/ZusWhnMKGjpQjMLXBOSAlCBB+3YqAoBmAC+AIwJIQxgEaAZB7iGDD2UchlIx4Z/+OBNQ7nZDjU5cnvT2g0HVK32yRqxTT40mOfDsiRCGwgAmEoNBgw6bsPXPoRtQzMBDQ5HE4grpDRDM0vVYpKVti7t27e5pWPPjiV9z29PNQ0CoBHAnmqe3PrGfOfPDRWyu18dPLkr4VoizRgqXggdt1E0AeJ2HGBAKA3OBz5mJ86tGqosrDw0PfZzKWHnljSkT2xq7/kuEf3gPaSVxUQpu2mskG2qxAVixMCFhK88uIKhKZkcaGhoPtve1l65ZggAAO3t7bNzIyN/bYeV+ERpocVi1KFUCF3zISlAQBolzSEgIAyD0CGIcwgyYMSBxauBwUBQdHXYpMFUAD05Db8adJ+cmPvF9m3nH1x9224rsKTbbzykpA0bEl4IlHWAWLIO2vfghBwmZsH3CWQIFgFWqFHHLdzc2TO2o3vt39ULa2p734onG+FOrfzh3IAHYP8w0dGZYGHV2ob2z4zm5++cLBWWH58c7s6Uq0jXxWA8BU8rMEvAStjIeQHy82PsQn62N86t3qSh7QNdK29ZWL6272wt//3Vbt3IT/IRztdq7cPT0zfPLGQtsjQUCYRSgSuDBsctLWtqez3VuuTIh64D/DRoWbZseu78ma/ZoR+ffu6VX4ZXEWZkuNHVISAMAi7AuQVhGFwyi9XzADETlUUtWkpOURAZGgWHMwS5MuwAyM/Mx4enJuL+xChYfQorf+5h5AIPoTBQiuAKF8VCBel4HAiiHAUpBYBBgMHWQHMyhQ1L+87sXrn16/VANg4UVkTG4x1DMgAnThOdDfJzj09UK6tbuPNbr08N3TRdrNlGSjjSQiAZPKOhLAbbTaIEibwXIM4MKhODayey8/9uoHfVA1v7Vvztm5X5gToWn1odj08SEXs7IUQsFvoW7PmwCsu2ASHABEdKSyxh7nQbs8ZW/pSJrA+dAADQ0rd2IHv62F+WPOXUpqeXVrPZe0xu1rXIIGQAGQEdBuBQgG1H3ciL7gG/5CkYMAKMZSEEYIRBUCsiGY/DL2QxsOd5xFsawKoaKz/zCQwjgEymYWqAK2JglgNfh7B8QDIOwS0IzhEqHzNeCYdGzt2ykC/9WYttn+isa+gvLVv5LBGNv9tdvdhFdGyQ6ExDzJna0Lv8Y/0zkw8enh7dvlArx/OBDyEAJTmMAQLtgxNHhREM1/C8bNPc8KkH9mdGbqnnMruyqe3sd7IXvjcKPD1MtLAMMIyxYJyo8cDk4KeOj5zfqeIWiAEBJ/hGoV3aWNXY0t8mEj91J9ZVIQAANKabLnQ/eO9fV4YnNtSmpju8o+VtolyEzQU44zCCgXMBuuQTRleAhgCgwcDBEZWnV4MAiWQM1WoVqlZCfSoJOwBUvoSJ5/egoCpY+8XPI+tXoY0AcxxUvAocIQAYkNZQFACwYWwGDwGO5ybrBmczd8Y4v9MOdH7nxOqH7ly94X+dpPIrG3+MB7948l4jor3Hl/R959Zy9tbB6Yl7+ifGbj49O74qG4YIHYEaCEYIcMeGF/oo1jzM1jzUmXK9o6j+RG6675XMhfse7tv43Y+t2fAnSrojp6nGpxGkzubn7hnITrWHLgcxDpIMVPOQtGysbOl8res99BdeNQKw7u4agEP50dHz+fHxlXOlQrvff64zQQKaG5BkAOOXwoPICEbnn1iUOwg5h/QNhAKMJLiuC8/zAF+hntuoVEqIxW3MHngTR/0A237hM/AaG1AgHw5DaIWhZXMBiwjaj+5pKRhqnJDXPmokYECwYOoLAyceGp2bXnfPpm3feLE682zSoFKfiE2uZun5HyOLDwwSZXY1LXvifM/c+hdPH/3yvuGzd42H5TZFChTj8MsVMItBJB2AM+S1hlQaZYTIV5T17RNvfv7I2NjNy9s7pxLpZM5trs++cuHUA1PVIlQyBSIDy3JBYYAGJr0G6byn5tKrRoBLilZPz8L5I0e+VyuVmubylV/CTCZF2gNnBIQAE5EPwM1FzZBgGIfmiKwDaUjBEFQrsGMOYpYNFYQIhYFt21BMoamqkX/jKIa4jb777kE67oDHU1UtWSlZ0bJN2+3GCKiAoG0BJiRIGASCQcOAJWzMewFqhdnlM4f2/usnzIFf60imZ7Zt2PT0wVLuW63Jhsl3SwuvZOxiyftrZyuV8zetXrP98MTw5w4Mnb0361caiyC76PmoGYJ2JAJDCHnUWRVAoYoKJmeHlvWXZpYFjGDHXWSLeViNaZRVAG6iGynNLXQm6jJJKWevKwIAQN+2bYdO7tnTVj47tCOsFLeH1QocJiB0NKyKEYcwBE4MhjGAE/TilQAH4GBwbQs6VNDGAJaAEpGlYGGIuLHAQoW5I8dw9tRpLNuxgzY/eM/UQso+9/CGnc9WTfdvzs7l685PjffOexVUpIDhQFVHvXw+EYwlEFoMVXgufK/rjJfrOnZkYft+OvjQ6vYlZ/aWF/6wNVF/ZkVUPvaO+v+aRGKKiDJ9Dc2Hti7p/ZhndP2B4bO/dnzi/Pqh/Gy6TArG5iDbhhEM1TBEjTEYKVELqyBLwCuUYQmG0BhIWyJu2/DLVSSki45U/UhDMj39niwxrhFkMpnEwrHDnxp89Hv/tnD25AYU5pGsejBawCYDmwicAB8Acyz4lTLqLBtlzi9FBewyJfmi70AAJCkYZlDmGgG3EbpppLdsKq7/zENfx65tT+Tblo1LsvxRnVnz5J6X/82+zMhthbiGv9j/Z7hA0a+Cuw6YNnC5BKkQAWnEfcISO4U+q65/Zbp5YFX70oO3bNrxl/VA+OOKRYhI9ANC+37X4NzIXU/0v/k7B+ZGNuahQcTgM8CTHJ6USMOCDnz4EiBOsJUGKQ3mWKj5HpKOi+Xk4PNL1v/t7++6+cvsPbSUy2uFAO3t7RUi+mYwn9tyylIdbHKsyTs7gnjggyRHRUdNGrawAG0ghIDPaZHDl+UP3kZpYhKGImYIAlziQK2GhXNnEyeepAfuWLvhe2uXps4AwDjRdOcdD13YMj3y868PHv7N/qnM0rJjWIUCJONuNDHMr4IzDSkWC1xdg0xYRSn01p0rz65rWhi7++DC2Cc/sWnnfz9QyQ82xetOvVNItmglNBGNtHat/mZTKjW2cWrkswOzE7sL5Wpizq+1DeVm3KxrABZCGw1uWRC2jTAoIxGPoeZ7SCWSYDUfTfX1YVtL+7npkuMAuP4IcNFxGj5z5ukmePfIwc66sbGcjFVnISQDtyRUqEAcYKGCEAIeKXAu3jr1l5m0i5QwxiBiACCZBYsEXGOQy2RErpRbMfX6vjsB7AGAbsZqAM4eIvrPm1taXh9RatVYUNz0+N6Xfvu8V+SaCFJKGBY5h4yAms1QQoiqLREEAUZVNj0+Xd11ampkbW+yafz2ZWseez43+1KrdOc2p9Pn3sVZrAB4foKKRwrda9oDxq2B3Ozu548d+tVD+fEdRWiUBEPFD1HzaojVp1EolJGUDlSgIX2FYrli5cLqkipj/LrzAS5HLNXAW1asTsfqGoWeyGL6+Wdg1WqocyW4AaAUOAkwm0PRW4kkE7kGeLuExqEBHuUVOBGgDVwm0MglYmUfdhj+iOq2I5JkX3+dKheWY8lrL+O1LzjgbSEYNBdQZGAMwSEOrRWcWAK1Sgl2Io5QhZgPA5RrtYZZ8huG3pjqtvY+/0/v2LJz/zOFqa+2uqmxbXZy6J1k3y6WzgLIAsBpov7u5qaDy08c+a3nzx65PydEay408JwYcpVqlG+wLCg/hBWLY7KUxxtjFx7a0br0SQBPXZcEmJ8vrS1kJr7sh2qFqE9hyX0fQ608i+LBExBVH7Yx0CzaTOgfTh1fJAGBQdBbvx+zDEIAigBmGHRo4HOCxSSYJthCvGvxpAXtSzBuBSZ0LImCjpxMblsQAGRgkFQE43moc2MgMFQNQXEgSNqYCX1UHNnguKLhO2cOLn3m6IG7f/6W2/fk1677i0Gik/WA9249hYvC0puDRL+1c8OGW0/lpj+dqVU2PvPmvptDHQirOY3c3DxsNw7NBQo24WhhuuvZgRNfPjc/f2x1c/PkdUWAeb+0dnp49E+rc7N3VZWHolBINqTQ/fF7MVYIUDt5FhYjQDIITSCtwcUPe7GGAexteUWlFEIeZRFsboFsjpAAY6JpZ4zoXXX3m5DKjwAVLqPrhkiDMwHOCMIALgSWycRCWXvJ+WLJKuoauCNR19SMXG4BjhNDgQHaeIjFbdiCWr51cv/nXzvy5q2/fNcD31zW1PpmNpt9/sd1R69krDhM9Ep7or4/D9XTbOwv/e2rz31hZjqXaky4CIjB0yF8W2AOCq9Pj9zVGav7N29eGPh2X13TsZ/UeX1NEKBczm28MD72F3Oz07dwz4dIOPAUoeYbyLYONGzZgqlsDguFGTikkawouEJAS8LFWiBajATeHt4EIQM5HIpC2NAQQkABgAY4A+iSzvyjGAJkqVptrFKQ9JiG7ViAYfACHyY0qIvV47Obb//jZHPD2FPPP/W7Oa/cWqSweWG2JNKWBc04QgEw6aDMCCImENY8lKrB0omg/Jl4kHSK8fReAMWfVAIGYPw00cxDyzZPNPPYyN/sf/53hv1yq+1YIAGERiPkwHBQiP3D6MlfPzs+vOuu1Ru+RkR//uOyjFeNAEQkM5nMKkvx1ZPnJ39/Lju1gyMSdgLPhwWGBp6AZxn03nwzinMTyA+GCHM5WOUANuMIiBCjyPP/4VjgMiLwGLgjof0qSIfQZKA5QcKCxYBoEN47wwV4KQ6ImCPDmoEKA7jcRsx2wHUIbjSahDOxur7nyc2f+uK+ueJc3+BM5pZnjr/xxTFL90yqMiSzoaBhJItG6cQ4SHEs+N4SxUV31eZLAfxU42YXr4WR4XL5r3M31Tq/dXL/P5uuVbjkDDY4mCHkdYgLqMXKlepma/L853Yl2p4BMHhNEWBqaip+4cLQF6ampn4PpPqCILCjahYGYVmQRCAiFO0QlpEYERrdn3oYW9WD2PfotzF76DC4MBC1KgTVwTADbQyIEaTF4XllxFwHpA2IC5iqD8k5tLRgSEGAQ5GCb4XQWr/rGlQAaQAShoUuCRR41ObG/QBlCiAojnjMKuxmbBZRr+S5c83LX13Z1nHw6PTEZ74/feZXFmbmsCAZQmIIAxX5IkRICKmIqRSYst/r+vUmk5lj5P2xbQvrW0df+/Ua42KklEc5JuE5LmaNRll7Qpdndz8xPfAbRPTv3m2czFUhQLVa/tzszMzvaxX0AdFmX7rHL55kFvUHBIZg2Q4UDGZVBbseeQSv1TwUTp5AIzkILYLWBsIRIBXCVz5isRjCMAQZDclsIDL6IOLRfD8DwEQlafzH5N5ryAsN11VhyBkItmWD+zoa9iQELMaoUq00XRbS0WIM/v3DXqGfbGn9zdgPfkkTYBbDVc4YiAhaa6mUjvOLRQ7vEXVwxtY1dj750JZdrSfHR+6cW1ioDw2DZgQVeAgZIVPJ49TC1MfOzk8uBTBwTRCgUpnrONM/9OvlcrFPCAEODUYGYATGOSJCRO0ijHNoQdBKI+QMIhYDHMK2z3wGBxcK0JMzCMMKXMdBEASA0bAtGdUVEoHAFsUBEdUewiySgIGRAkgASjnvbh4tJwCzyJKCVDTfQIMgBIfFAaZNaAnxjvfrNic9fJhipwQBgiKFKlyMYKKCWMbBmUWLZenv2Qow5hHRnqaGpnNp2L97fnrqf6uFZWksO6q4toG8CnGylls3XayufDcC8A+bACMjmX8VhMFWIaKJmWYxmSEu8+cposGiZ69gOxaIAG3HMA8Gr7UZ6x96EPPJGIy0UAsVLMuGzSwgJIR+ACEsSMcF8ctEIXCA+OLXjn44jFnvJNMez1a7TszMPnQsM/yLFVJJDUKoFQwDYAmQYCAiE2fWO4ZxhwFegXKsxemgAgycsUtqJWMMXAjN2M8uxzPGKpvhjGzsWvbo+s6eczIIIcIQgi86hTbHuPLS0+V8H0WDsK4uAfL5mb58Pvew8oIEI/NW9S8udgRFJ5ddFHiNAWM6kl6NhvZqsOIuckwjuWkNej55N3w7hkypCs8AdiwGHRo4lgvSgAkNNDMwDFAssggKgCGCZoBmANfkvm3z2YsL07u+d2bfH3ztzRf/7O/37vm9iVoRyhIXa5IRMkJIJhqFZpR4p++6HTDMsQMBFvU5LF5zFP0bMMYwY4wgwvsqEWeMBcvdhsM7V6/9bne6MWCeD4HFLKYUKPgBRmbn186Pzjde9StgamLmV4XgrRW/BiKC4zjQOrxkFmkx4XPRJWCLp8WECjAKkgsoz0MskcBMpYTl990NOVtCW7GIoTfegPaBmG2BMQGiENoYCMtavFIEdHQpLOoFUZmZZzFJRAIAna/lljw2euH2F0eO/suDF0a2DqLAHGVsP+2AcQkYDcY4DABNgCLDFeHdmi+MLPucFh1axqLOJ/YW0UBERMD77hHoALxVLR17NnQt/cWRs9kVFaOjgZQG0BAYLxdWzYbVRgDTV5UA5WplC9NUDyAqXwbBMLG4IAAjFg2YpLfuAq0JzJIwFsGyXXACyuUqHMvBlOdj5Wc/hWSoUZEM2SPHwH3ABB4cISCZjAZdMwZDgGQs0vAZw0XLO+pXWo9MD35+trawciI3v+vo+OTtZ/Jjrk8W0JCACjS0Y8EEAVwmAWWiGnwAzEAbMuJdTiZ95dTBgEUDEyPSMQZib10BAszDFSAAY8yc8YpTKxtaTyW4WFFUCuACOlSQIokZ8tvzDmu66hZACkmFQgFSSggGBEE0gj4y93RJzGHsLbNpyTiqQRWQDNyEYMRhWw4459CCYUQopEIft376YbxRqaB2bhA2aRgVghFgiWhEDWdisRGFRYKRiTzyAyMDG/a//INfGKpkhLIF8uDwkhIxclD1ahBMIgh9SAXEXRfar8ILDCxbQnKhod9V5+D/ffCoTTzadE0Gyrx1+hljRkoRXKm1bXVSmbZY+nhjMv1zsypKXC3W1GCBVGNRsqZ3ml344TqBDIJzHoVBBFiWc7HGZzEANDDMwJCCpqh1nIyPGBeIGQlLc1z0mUMyMFKAtIsZ4WKsPo3u+++Hrm+BMDYS3IEEoIJobKlvPHAr2nzhG9THUmDKYCyfXbdHLIiJuMCsBfhxCRP4KNnR59NCRKdVAhUE8DiDJezFNnYjKqTj7/Z1hSECcTDOFi0eWyxmZdDEeWDgGHZlDmETY8XlDe37euo7Jq2Qg8EGwQKEh3GdbT80dvJzk6VS3VVzAolIgMC4JUEGkSRroiiAiH4oj09MgDjDxdNjFn+8RSS6FC4qRoglYggA2C2NWH3nLlwIyphlBN+1wWI2tNaI21ERiSYNnxPm8vNwXRfalYDjIJQMAaJEj+M4QNVHWKoi5RESvoYMNCQDpJSgRX8FBhRCv2sYCUPcmKjL+aITyDlf/MEgOFfsChbl2LZbiAkRXHzaR9oCpAHPKJRCfwkLw/jVvAIsz/MTtm2TX60xz/MgpbzEQ8aikp7LRaHovNBiObj5Yb13ceWsmItSuYikLeGlXDTs2Ix11SIOPfUMHD9EBwMaYnGYahmOkAgFwF0bYTUE4waeXCSXFFGncqAgyjUscRuxYsXacoN0c9O1hfbz02N2wVAUTRCDAEFzEoHSLhHxdyoXN6QF5xyMGVz0BS46hYtikLiiqXTBy0IwDa0BxmFYFHrWoFEinfaMiV01AjDGvCOH3hwOQn8zcVZnDBC9QKXfls6N/IFo1ykiBkWXxOXJnujnBoHvIW67CE2IwLExTwZL7r0DvuNAzWQx89qrsJRC3DBIC/ChYZiG5VoISlUEALgXgpNBPAQco7BE1tW2tq3et3Pjtm/Ux5KZQ5MDj+RmM18shjWLcQlCJAhprbkX+nX90Tr+yH0ezfhdTF//sPcPYwyjd3Egf1b4TMeMMQIsuk61MYghBnADJoWWllFX1Qlc0t3zR0OD57YwxjbHYnGEYXBZWBR1BdNFW8/f2TL+cM0fhwl8uG4MnC9WCDkWDBdYc+/d4AtVnKyWMfnGYSxPphB6FUBGzR/ScNhcwNHGa1GWaytCM2SlK90ytnv58sdv7tr8Dbe+ccAC7Plk3VLX0CMAWVxyMCZgDMEQeDn0mgDY70QAMMa10dBag6QAgcB4FPJyziGE1Azsil0B2VKxL1+tpMAlOJegMAS0QVJYaHJT5zlz81eVAG1tbSdOnz75OGCStVqtT2sDydlbIgmxS6eFIRora0hfOvFvqfaLQyQYELcdeJ4HNx5DpewjkYoDnJApVZBKxdF7z71YKJUxeqYf7a4No6O3e6CixxuaQjlxe+uy4rLGpkNrG1oOtiRbzq1v6Ti0WB4GAOG3c6OTLpOBBYaAFmNWzmAYRLlWa1kkwI+6vJfu/ItjciOXd/E7ssWpJFeEABNETd8dOHzPeD7bajgHGYBzC6QNmhDze+LNh7vS6fJVzwV0dnb913jcGclkMr9bqVY3czCYRWeQL0bnjF28C6K7P2oMXRwjA0Sl4YtVwCEFiCXiqHoBbNuGCTQU4yDHRVEypLq7sOyuO3Eym8FCqQhLERKLkUgt1Lhr9eYjzk13/FGHTI1vjcdn32naSMJ15qVgRIpgVFRiRoygiaES+k0harF3llkZf7sPcPk1QIa4AV2RETKZoNJ5ITe3bbZchk470JogmAQjhQ6ZmFydaHrjnUbHfei5gIaGhnxv76q/6enp+a1YLPaiFHJCLIZaP5wSJJCOBiGCXV61wcAX5wstjpOCFwYwIDhW1FSq/BBwbJQYsGBJdG7diM333YM8KQjHiswjAxQHWq3Ewrp02/Gt8fj0u42asSSgteZG66gpdbEUPQhDqDCMMy94x5QuMeJaR+S+GO1cLn0zzkheASHoNJFdM6YuH9bqa8YA0oIyUfOcEByNdmyuxW28NpJBb1mCntd33Xr7g2vXr/20IDbgQEDwxWody0YYaMQgIBcjAyUYjCMRSAafGRgwGAMYZgMkILlAoAOEQoPZDEaFcA0A7iADjrodO7HhE5/BuC8xTwIlKeAxhbQtq8uiZg56t8IVZVnMwGIJFgdJiapRiBkOLTnKnm8b13nHvys0M9xEpWSaR34Ng4BgHIIxYoxBEr2vcbREJGyAHR04+UtHJ8/38foYDEIIaaBUGZYIsCaZPt5IleI1Uw9w2SkIARyanJz8vdHBwT8LvFoXGEcQBIjHElCBAlQ0SIq4AakQpCNdPcrycQhzmQWlH+U1hQGcpAviBj27bkFXz1LMnTmLoVdehqMAi4t3PAizNJt8M5O/4/G5ocTxbOaBMteNtSCEMRJScOhQwSiFQPnSC9SPXAH9gNCkHc4FOI+ynZoMDBGUUlAq4IHy4+p9+gBDQONEdnr3m5Mj9876FQQimsrOXRswhAYh0dXYPNDS0lK95ghwycR2Wi/Zk87BUJt2i3NZ9WpRTtsoxKQFwQkgA01htFNcgpiBJgbLcERhD3tHg0YcqPgBKkojSCWRWrsaMddG3dwM8m8cgTZwLr8biYgNoNS0Z27qrpfOn/kXpWqx83R2tmdaezCOBBcCfujDZQJcSgQqlMz+0fAqDQi+6OBerE/AxTQwvxgFMPN+hKBhWqifC4vLDk5d+NWDM8MrKxZDzI4DOoDNLVjMYIVIn1/Z1Hnw3drarwkCtLLW8vj4+B9Pqsmmcq1yu7Ciki0ekwiNwmKZCAiAEIsnyZjFUJBFu8xM5By+7UqVrgWlFbgbR0kZlEFI9/Vi2e234+jINELLSRKR7Ac4vIX2JzMXNrwyOvBrB0ZP3zfmVdMaBhWLwZccmgygASk54rEYzEIJxqtpBvtHCNAFKIBxg6i/MfqMBLYYBQjJIIQIDdTPtAdnqdL55szkI8dOn/1Uf3nuliwUNJcIVYhQ+RA6xBLEsbW+4/AaJ3Hs3YterhF0d3e/PDw2/B+qQ+fbjVKrCAYaBDAZNWJoBSmi7h5NkUWQPOoS/qGqKnbZr5hBoIJLySVjOJglUYFAekkn2m69CcNhZVWhlNuZq1Za940e+/VDo6O3j4Wluqr2ELguCAqh5NCGEIcNpg2UMQjyBcQV0Flfl7U9j97hCmAhGRecg7i5JGVHErKBUdoorQ2HfM9Tx8eJYodK4/d998yh3zt+7ky3irtQrgWfGWgoWEkHTinA0nhi9NbOvsd/XGn4NdUY0ru09wenDr35zfP9p/9NMm7ZsZiDwGHgXCKkSCE0XC4mVDQkYz9UVHIpX8AW548yAyntKMQkwGIShgR84wPNTei5cxfGu5pavnniwA8Gpib4hJlLzCuFmuSwOUeoQziCI/R8WJBwVQAZhKhLJMECqNUdS6Y/vnzz15rd+h8ZGGEDjAtuSETJKMYJbPFzRKkMrjhQYKTf08soRMSfzY099PTA0X+xb/hcd6XRgg4D+IJDcwZbExpgod2W3i1L+17c1tPxwo/N0OJaQ6m0kO0/GyBm27HGRoi2VsTT9Qi5jZo2AJcANAQzgFF4q6Iq6giixVvAMAOQAUIFBQNICS41dBiCGMGTArIujT2zI33fL+ahGYcXV6hJAiSHNASEDKIaotGyUWe7aGJyoS0Wm97ct/Jwkx0/vzTd0L9u6ervd79D8+cKwLxA3CgiaGjoRZGLAeBcwGKiZnM5Jcj+qSzAeaI6H17918dOf+HZ/kNfenNuYl3BMgglh9TR1RIHQ2sA3JRoOrm5pW3ffSvX/2lHqmPuuiEA0Xjs1a/v6Zs7N2jNFwuYsiX6HngACViwE3XwNYdiBCEFNEIYo2AZ61IIEPkEUUpZUFRf7DILsAwCUuDEYLsWtCKUah6SlsAcEbIVA1dIeMaAcwEYgvYCxISLpHShtEaHm85/atvH/nBjS89TS+zE5Bqg8BMejSCtQ0ezRV+FonIyrgFoA2NImwCauxT+BHPfODY7vePQyOn1o35xx7NnDn3idH6m3o/Z0NIG8z0kmQtfGyRg4ZbGtqO/dct9/3xX45IDP81E0muKANk3p27VJ4/d2zkz4biVGmq5EuYX8mj4+U/C2rAJgluQ4PB0GHUMK4JnVWFxByY0YJCQwgZIIyQVzfLlGkwDDgQYA0IVQBoClw4U47C1A58XIFgSAg6qFKKlGiIlY+hE0pNM+et7lh+9bdW6v9zesfqJyyZ+/GRCcxHaBnAVIbSjKMAmBmMMfMGcgLPkO5l4xpgZJqq/oArbnh4+9MDec/0/1z850Vs1ZBccjmI8Ds0AUQsAFkONc9Qr4GPptsO/tmn3v9vd1LX/p/2M1wwBLhw7dtPJJ5/8jZmDR3vN/BwYOFylUJvL4tiTz2KtR2hbvQZFDojGOBZqNSTsODhxKF+BEYclOEgpGDIQUkYJJW0uVuDgndoAjeRwbBdOyMFDjThjWO00VHqbW2dXptr3N8bc8S0rVz22O958+D3O+GUWmEeWgIJGyKJUshAcTtLGnAjSae5/7JxV3vViZXadRSbQ2lh7SlPWU3PnUz8YPLTlbG76rtfGzu+Y98oIJEEyBzUoBIGKIhErhqL20U4Cdy1ZtffTK7f857u7Vr2nN5auCQLMjY11Dux57uHc6wfu4RdGnDQLwTmHxRisUKMynsH4408g0/4GunffjNjGNRD1TcgXfSBuA9zAFgLMELTWEFKCMQ5fq+gLUhRGXko0XSY712o+kgEhFTK02An0tLdl7mrr/fqWpSse35VqfXPxz/8ser0RBB8mKkQVBtAWR2AMKgI4kRnDVK3Qc5jY/1LFShDWKkZpwzUi+bjge062VkZeWvCYAbMkHIuBmAWpGZLgaHXj2Bxvnd3kNux/eNmGP7une+Vz7/VDXnUC0PCwe3jfvi/kX9n/C2J0tNkNPHALCAIPHBZczSDJwJubRjWXwfG5CWzgn0Z8wxbE3TQKJgBbLNUmpsAEgTOCMgRmJMDfXWsjIrTAwdZEB1pEKrOmY+nebatXfuOhVNf3r8CcfwMySgQaNie4hoGRhDEKmjTOZyYwOj8NRkxA6ZgxBoYzmMVZBgYAuRLCdmFzDo8UKtpHXHMsIYFtdZ0nd3Qtf2FHc/tz3Xb9yZ+2HfyaIkAud75utH90V+bFl39JvXFkrVXMQ/PInJM20DaDUQG4zWGDACiIQh7H/v4xrA4YmnbshBfjCLWGUtEscSkltDZQgUI6kUQQqksn/uJVcNmvK5vr28d3reh5fklTx/dbE03HSpFzdyUydIykYCQEDDfQixlACA4mObwgBIggtYzG3nEGkhyQItI2Qg0RaJiwgoR0EAs14uBYk2wc251esufO9r6/v3P1uuff72e9agRYOHNm2chzr382mJjcEZw+vSE+OwtIjVAwcGHDtiwobiAdC34YIuQamhu4QQCb+Tj9vcex0Rg0bF8HOA6M62DB96GNgWU7gAmh9dsc7MtmyCymZAu3rFz7H1uWLv92K2NX9KXSIcCqWqivWoDHGGqCQTMTdQdR9G4iYwDcaPNNaKJm1kgngssIdZaNDsbU8nTrWIeMDbc6qZGtHd0vrq3vemrlFXpx/aoQoDw83D741JO/Mbr3xX9ilfwUzUw5YCEIBGEkGAlAaxgN+NKAFCGeSMAzASRnMOUyWoIQI49/F8urBfCGetSvWo10Mo4iCMKOTpIKAzDB33IA3z5AypCQpKwrvfkAUAtKvSOz07f4zECLaMNBFLUEhho2cUjO4RULsCwLMWYjwSS45jBEaJZObXmqYeSWpiXPb2lf9oOlTXWHRLKteKVfJ/vQCbAwvFB/6rUnfnn8tZc/b86eaqMqA1MelAtAA5YW4BDRSZYSAWeoc+OolWswkgCXweEEUSkjbhQGnn0etVgc6x7QaL15h/bBhV/zABjYtoA27IdqSSMisIvKQUwz3XDl9QwSz06NbD19YXBFpEBGwpICIS4FbAPUx2JwhYWuZGOBM6FTkAttIjkdc90FIZi3LNF4amNT54sN8boTa1paPrBXyD7c1rCpqfjAM49+eezJJ75sj4wtSU9UUJZRkoSYBcYISgAKwWJNIAchROBHZd2aK4R+FTHhQsQSqDBgCSQKlovR4ZFK1x13fMtx3aWkw5u1X0sypaMS7ss8f601mGBRWw8p2yX7ij/8OIxK8+nczMfHq6VGPyGgtYZLURYwVvWxPFZXu3/d9qfbneRAdyW80FTfdD4lrJk47Gq96+br6+t99lZJ2geKD40ARCTOvPjcffOvvfkpDE8tUYUS8hZg86j2D4svCBpEmTNanBTgagFlFMphFTJlQQQCgVYIhEBqaRfYyrWjzS3N2SW33vqtjjVrvtvIWGJydvY3vDz/BVJBq+b6h6pxLlbzMCYghLGI6IqvwYXZ4q0Hzp68P3QFPBnp/woKMEC9Am5t6dl3X+fqP2pKpUZTyC90ss4qrhI+FAJkjp/tnT55pHH+uRc/Fx4+cRMv5GCHBn7MAgvflsBd1PEvNs1yLWAn4zChD6YMYBhkug66uaVibVl/uvPhR/6bScbKq3ff/sRFoSY/M/Ofs05sXHnBz82Xs7d4nreoD/C3RQRCELErVpo9TOR68NpfGjj96YH8TGcuzqDAL7WHO8ygJ5Yo3d7S+81d6bZ914IG84ET4NSpI5uHn3rmS5a30FbZu/9hmZtD1QrgEoerJMxlUrhZzOBdTOsCgKIQxtOwCbDgwLccBE1t1diunS92P3T/1/rueOC7b/8369vazheLxb9gIfuHcFL/MRUK91SrVVD01NDlUQDEuzwE8TNYOPssvPbxcv6Tx6ZGv1RJCBRZCBYQQmOQ4AJ98Xrc2dL70vq2pc/iGsEHSoDp4TPLTj/17C+WX3zlV6SXi2FkJC5YCC0YuBRgoYYSBpfGwNPloyEiWALQysBJ1CEQDnR7a0Fs2/B6z/0PfbXvjnsff7d/O52Ohi4uzM7+a2HZ/yfL5h6p1SqS9OI0kkuRwZWpyz+HUu90rdZ/JjvF9w6cxJyj4DSmwQOg5leRZAJb3MazDy5f/+cr38M8/+uWADQ+Hju+99WHai+8/lkaudBUozJsE8JmHG5AYILDUAjOCIbMpZQuFl8QvYhAaZhUGvbS5cWgrm4+vW3ji1137P7uitvu+qlOUUNr69HsdPbfEzGOHH6hWi0LvpgzNsaAsfffnTNK9LuH8sP/5Xuv7sGM8lCOcTDLQlAuocGJw7Ykllkp7Gxof/bWjmUvXEsJuA+MAEMnjj6ce/7lz5v+s8tFtYQQQSR1eoArOXwRghDAZiIa7kgcgjFE3QG41BkUJBogVi0ftm655aWO3t5T7Zs2vdi1YcPJ9/JZmjqa+nO53P/LGYQQ7OdNqITSYfTOHkzd+zD7Vr8J/vW3+vf+wSsTZ3Fsagg87qBkMXhhgPp4AksCjpZEGjvrO169eUnvoz8hhfzRIEAmk0n0/8+v3J07dOwmp1YCMwEsrWA5SQjJYQuBLIpwQdEg50vdQJGzRJxFVTSMwVmzZnDFZx76y86P3f5oTIg51tv7MwkhjY2NJ+fmpv4/Bh34Nf9+z681hmEIGIq908NMP8Xm88nQ+8pzZ4782uOnD2BQFaAb3GiOkOCwmIBlDLanWzOrmzpObWld+vUt3cvfxDWGK0qAsZODfRU11zb06Dc+Hbz4yufdwpytvBCutOEwC8bzEVqAJxgsIxCAI0EaoQZsbqOmFEJLwiaB0I3B2dB3vumf//bv991z5xPsp3wF68ehpaXzEBH9ZjY7e8/U9OR/LFarHWS7C+9l84lInIXfdw763MG5Efz9yb24oMooxx0ozhFNfTJoYgx9bgr3tCz75qru7u/XtfftwzWIK0aAybPHV598/PHfCOfne2oD5zbR9HS9Va0AcYmAFMhEFbUcPKqsJQFXCjAoaGZQg4KRAnYyBsPj4D09E8333/voknWrX74Sm38pQ8NYkYh+EARB3BjzRWFQ+Gk3/rhf6vvb6cEHh+amfidfK+P4xAVc4D48SwLgsJkFYwlYYYAVdhp3NC47sKln5d+sb11y8j2+DHp9EWB2djZ59onHfqHy8mu/mFwotQULM5z7VTi2BV97MExAM4CkhIAAjAEzAVgo4RkNuFbklccciN6lZauz+4K7YcsLXZ/81Nc6Ozvnr/SXZoxVieh7QtgjHhDPEqUbgeoM4LQzVgGADFGigFKMkPIz1eKaPz315mdPTY7dezw3sSmrakJLhqyqoSwFrHgcXhBA+gESjKEHMdzV0LP/M8u2/6sNbV3HcQ3jfROAiMTgSy/cUdh38OPu1ERHolaDKhfghx5CzuEYDS1ZNLKVA0wsTuoiQgAfjDNIKwGyEzBL2vKxO3Y93bpl+7Pp3rWHu7u7hz6oL75IgoMHMiO/PrMwfFNTQ/0rAnbhIHnBbDa75k9fe+aLF6Ym13ik3CrXqelSobXADIqcEEoGBo5QCiSlgyBUEFqhxYqhW0ms1c7I7lTn327r+ulLs65bApQzQ42Vg8fupVPntvuFGSzoAJwBtiPhui5MyYcQFgADpQ2kIUgBGMGhALjcQTWZhL10VSZ9884nm+667Rtrdtzy+ofhLTPGgv9xdu8dj/a/8XmpOYhEoKSQgqBmq0W7FkTpZe5YqCYFqiIaEOkFAbgwcLkNUyiiRbpoZQ66RMx0wxre0tD+wqq2pudxHeB9EWBmcLDv8N8+9n8Un37p83wqk2KC4AvAtSz4tQB+sQxhxSFkNKFLkIbQKhriaEkY20bIY1DLe4db7rn722vuvPdrTetX9n+YCzCnA+dgYRpJEYe0bLtsCI6GXbMIUgpwimQCXxhUoGBrDlIeoBkkKXTEYliHVGWrbNrbIa2ppOPOrOxb+d2+7r7BjywBiMheuHChfeLQoQcqBw9+kk9PtVlaoaY1mGEgm0O6MdhKwyNCaEIwrmHx6Cm3UDowzS2+bGspINVYaL9717eX333vN5pWfribv6g/V2pWNLSJBKFCBnECQr74VqmQEJ6C9kMkGFAXGtSLGCxj0KgEViTqpja5rQfuXbXxP61du3Y/rjP8TASY6u9fXxwY2Dl25NTd4dCFZXa1CA2CpTkcEggCgrIAWwOuIIQqgKYQRljQlg3V0KDja1efa1q/8YDo7j6z9P5df9/Ssmz6aixAjFuleDwOiywE2kDY0bh6Aw2hCT40XAZww9BkxdBU8tGXbpir47Lak0wMr7IbX12/fNkzK9euPYDrED8TAfwjJz49c2jfJ9NnBtcH81kRegGMYLBjMSitYQUa3BgULUJCOyAuwLkDOA6osVGLVWuONXz844+13H77N+vr6/MNDQ35q7UAbYmG84+wpYPzzG/xuHbCIJCOsPySV4kbyTnpEFAa7fH6sEPbw6uaOo9tau3a5wBeXTI9uWX79idxHeM9E6BQGG8c+evHl1bm5lvdhQUnZCzK2IAjUCGYMpDEYJOEYQyhCcClgBYSrKExdFatPdN7/31/t+See76e/gBCvPeKB3rWfWVJiEFfoiEwKmZqypFCqGqtUu+DEmHNT8zn5rtb6xozXfV1Rz6+6ab/iY8Q3jMBvLypr5RKTUEhn3SrZdSMgiM5NBE0J1iSAUE0BjbUDKwuBjdVh6odKzdvv2lf2x27/6HzttseS7W3z18LC7D4atc//CSdI5PNbty4Zs0b+IjhPRMg7jjlRCxedOI2HMcB5wBpDaMCGAFAWiCLgTEBOxFDtblxoXHztnPxuubRntvufGzpg/c8cSWVvQ8Dra2tZQD78RHEeyZAsq1twW5uHpOtbRkvm693svOADkCaohw/Ab4KgXgCblO9btl11wt9H7/n0bC1dbK9qenk9bb5H3W8ZwIwxsLJPXsPpP1cqsqteV70dutSmbEwAHdENEo1IZBY2pVpXrPyTNdnHvlvTbfs2H+tauE3CPAzoLN33Su8u36o1rVy6wUZX6hMTPcEpXxKWtxACB1PN2Vbtm7a37l1/cttt+7ce2OZr128r3Iomp1NTmcyq7PDw5t1rtjiOsJnwg5lMrmQ7lt2uGXNmnM3lvgfCYiIERG7sRI3cAM3cAM3cAM3cAM3cAM3cAM3cAM3cAM3cAM3cAM3cAM3cAM3cAM3cAM3cANXHf8/4JBv2Ic8cG4AAAAldEVYdGRhdGU6Y3JlYXRlADIwMjMtMDUtMDhUMTI6MzU6MjQrMDA6MDBMjwNRAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDIzLTA1LTA4VDEyOjM1OjI0KzAwOjAwPdK77QAAAABJRU5ErkJggg==";

  // node_modules/preact/jsx-runtime/dist/jsxRuntime.module.js
  init_preact_module();
  init_preact_module();
  var _3 = 0;
  function o3(o4, e3, n2, t3, f3) {
    var l3, s3, u3 = {};
    for (s3 in e3)
      "ref" == s3 ? l3 = e3[s3] : u3[s3] = e3[s3];
    var a3 = { type: o4, props: u3, key: n2, ref: l3, __k: null, __: null, __b: 0, __e: null, __d: void 0, __c: null, __h: null, constructor: void 0, __v: --_3, __source: f3, __self: t3 };
    if ("function" == typeof o4 && (l3 = o4.defaultProps))
      for (s3 in l3)
        void 0 === u3[s3] && (u3[s3] = l3[s3]);
    return l.vnode && l.vnode(a3), a3;
  }

  // src/popup/App.tsx
  var isChrome = /chrome/i.test(navigator.userAgent);
  function App() {
    const accessTokenQuery = useSWR(
      "accessToken",
      () => import_webextension_polyfill.default.runtime.sendMessage({ type: "GET_ACCESS_TOKEN" }),
      { shouldRetryOnError: false }
    );
    const hideShortcutsTipQuery = useSWR("hideShortcutsTip", async () => {
      const { hideShortcutsTip } = await import_webextension_polyfill.default.storage.local.get("hideShortcutsTip");
      return !!hideShortcutsTip;
    });
    const openOptionsPage = T2(() => {
      import_webextension_polyfill.default.runtime.sendMessage({ type: "OPEN_OPTIONS_PAGE" });
    }, []);
    const openShortcutsPage = T2(() => {
      import_webextension_polyfill.default.storage.local.set({ hideShortcutsTip: true });
      import_webextension_polyfill.default.tabs.create({ url: "chrome://extensions/shortcuts" });
    }, []);
    return /* @__PURE__ */ o3("div", { className: "flex flex-col h-full", children: [
      /* @__PURE__ */ o3("div", { className: "mb-2 flex flex-row items-center px-1", children: [
        /* @__PURE__ */ o3("img", { src: logo_default, className: "w-5 h-5 rounded-sm" }),
        /* @__PURE__ */ o3("p", { className: "text-sm font-semibold m-0 ml-1", children: "ChatGPT for Scientific Publications" }),
        /* @__PURE__ */ o3("div", { className: "grow" }),
        /* @__PURE__ */ o3("span", { className: "cursor-pointer leading-[0]", onClick: openOptionsPage, children: /* @__PURE__ */ o3(GearIcon, { size: 16 }) })
      ] }),
      isChrome && !hideShortcutsTipQuery.isLoading && !hideShortcutsTipQuery.data && /* @__PURE__ */ o3("p", { className: "m-0 mb-2", children: [
        "Tip:",
        " ",
        /* @__PURE__ */ o3("a", { onClick: openShortcutsPage, className: "underline cursor-pointer", children: "setup shortcuts" }),
        " ",
        "for faster access."
      ] }),
      (() => {
        if (accessTokenQuery.isLoading) {
          return /* @__PURE__ */ o3("div", { className: "grow justify-center items-center flex animate-bounce", children: /* @__PURE__ */ o3(GlobeIcon, { size: 24 }) });
        }
        if (accessTokenQuery.data) {
          return /* @__PURE__ */ o3("iframe", { src: "https://chat.openai.com", className: "grow border-none" });
        }
        return /* @__PURE__ */ o3("div", { className: "grow flex flex-col justify-center", children: /* @__PURE__ */ o3("p", { className: "text-base px-2 text-center", children: [
          "Please login and pass Cloudflare check at",
          " ",
          /* @__PURE__ */ o3("a", { href: "https://chat.openai.com", target: "_blank", rel: "noreferrer", children: "chat.openai.com" })
        ] }) });
      })()
    ] });
  }
  var App_default = App;

  // src/popup/index.tsx
  P(/* @__PURE__ */ o3(App_default, {}), document.getElementById("app"));
})();
